﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace FeatureSelection
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        int DataSet_Name;
        int Num_Attributes;
        int Num_Instance;
        int Num_Class;
        int[] Com;
        string AdressW_After;
        string AdressW_Befor;
        string AdressW_Graph;
        string AdressR_Com;
        string Adress_Sim;
        string Adress_Power;
        string Name;

        StreamWriter SW_After;
        StreamWriter SW_Befor;
        StreamWriter SW_Graph;
        StreamReader sr;
        StreamReader SR_Com;

        List<Data> DataSet = new List<Data>();
        List<Data> Train_Data = new List<Data>();
        List<Data> New_Train_Data = new List<Data>();
        List<Data> Test_Data = new List<Data>();

        double[,] Sim;

        Random Rand = new Random();
        List<int> Result;
        double[] Power;
        double[] New_Power;

        List<int> Bad_Feature = new List<int>();
        List<int> Reminder_Feature = new List<int>();
        double[,] Updated_Sim;

        int Com_Num = 0;

        bool Sim_Loded = false;
        bool Power_Loded = false;
        bool Read_Dataset = false;


        private void Do_Writting()
        {
            List<int> Updated_Result = new List<int>();
            Updated_Result.Clear();

            for (int i = 0; i < Result.Count; i++)
            {
                Updated_Result.Add(Reminder_Feature[Result[i]]);
            }

            SW_Befor = new StreamWriter(AdressW_Befor);
            SW_Befor.Write("@relation" + " " + Name);
            SW_Befor.WriteLine();
            for (int i = 0; i < Num_Attributes; i++)
            {
                SW_Befor.Write("@attribute " + "'" + (i + 1).ToString() + "' real");
                SW_Befor.WriteLine();
            }
            if (DataSet_Name == 3)
                SW_Befor.Write("@attribute 'class' { 0, 1, 2}");
            else if (DataSet_Name == 6)
                SW_Befor.Write("@attribute 'class' { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15}");
            else if (DataSet_Name == 9)
                SW_Befor.Write("@attribute 'class' { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9}");
            else if (DataSet_Name == 11)
                SW_Befor.Write("@attribute 'class' { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 , 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25}");
            else
                SW_Befor.Write("@attribute 'class' { 0, 1}");
            SW_Befor.WriteLine();
            SW_Befor.Write("@data");
            SW_Befor.WriteLine();
            int Count = Test_Data.Count;

            for (int i = 0; i < Count; i++)
            {
                for (int j = 0; j < Num_Attributes; j++)
                {
                    SW_Befor.Write(Test_Data[i].Att[j].ToString() + ",");
                }
                SW_Befor.Write(Test_Data[i].Class.ToString());
                SW_Befor.WriteLine();
            }

            SW_After = new StreamWriter(AdressW_After);
            SW_After.Write("@relation" + " " + Name);
            SW_After.WriteLine();
            for (int i = 0; i < Num_Attributes; i++)
            {
                if (Updated_Result.Contains(i))
                {
                    SW_After.Write("@attribute " + "'" + (i + 1).ToString() + "' real");
                    SW_After.WriteLine();
                }
            }
            if (DataSet_Name == 3)
                SW_After.Write("@attribute 'class' { 0, 1, 2}");
            else if (DataSet_Name == 6)
                SW_After.Write("@attribute 'class' { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15}");
            else if (DataSet_Name == 9)
                SW_After.Write("@attribute 'class' { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9}");
            else if (DataSet_Name == 11)
                SW_After.Write("@attribute 'class' { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 , 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25}");
            else
                SW_After.Write("@attribute 'class' { 0, 1}");
            SW_After.WriteLine();
            SW_After.Write("@data");
            SW_After.WriteLine();


            for (int i = 0; i < Count; i++)
            {
                for (int j = 0; j < Num_Attributes; j++)
                {
                    if (Updated_Result.Contains(j))
                    {
                        SW_After.Write(Test_Data[i].Att[j].ToString() + ",");
                    }
                }
                SW_After.Write(Test_Data[i].Class.ToString());
                SW_After.WriteLine();
            }

            SW_Befor.Close();
            SW_After.Close();
        }

        private void Write_Graph2()
        {
            SW_Graph = new StreamWriter(AdressW_Graph);
            int Node_Number = Convert.ToInt32(Math.Sqrt(Sim.Length));
            int counter = 0;
            double Threshold = Convert.ToDouble(Edge_Thereshold_Txt.Value);

            for (int i = 0; i < Node_Number; i++)
                SW_Graph.Write(';' + (i + 1).ToString());

            SW_Graph.WriteLine();

            for (int i = 0; i < Node_Number; i++)
            {
                SW_Graph.Write(i + 1);
                for (int j = 0; j < Node_Number; j++)
                {
                    if (i == j)
                        SW_Graph.Write(";" + "0");
                    else if (Sim[i, j] > Threshold)
                    {
                        SW_Graph.Write(";" + Sim[i, j]);
                        counter++;
                    }
                    else
                        SW_Graph.Write(";" + "0");
                }
                SW_Graph.WriteLine();
            }

            Number_Node_Txt.Text = Reminder_Feature.Count.ToString();
            Number_Edge_Txt.Text = counter.ToString();
            SW_Graph.Close();
        }

        private void Write_Graph()
        {
            SW_Graph = new StreamWriter(AdressW_Graph);
            SW_Graph.Write("Source;Target;Type;Weight");
            SW_Graph.WriteLine();
            List<int> Contain = new List<int>();
            int counter = 0;
            double Threshold = Convert.ToDouble(Edge_Thereshold_Txt.Value);


            for (int i = 0; i < Reminder_Feature.Count; i++)
            {
                for (int j = i + 1; j < Reminder_Feature.Count; j++)
                {
                    if (Sim[i, j] > Threshold)
                    {
                        SW_Graph.Write(i + 1);
                        SW_Graph.Write(";");
                        SW_Graph.Write(j + 1);
                        SW_Graph.Write(";");
                        SW_Graph.Write("Undirected");
                        SW_Graph.Write(";");
                        SW_Graph.Write(Sim[i, j]);
                        SW_Graph.Write(";");
                        SW_Graph.WriteLine();
                        if (!Contain.Contains(i))
                            Contain.Add(i);
                        if (!Contain.Contains(j))
                            Contain.Add(j);
                        counter++;
                    }
                }
            }
            for (int i = 0; i < Reminder_Feature.Count; i++)
            {
                if (!Contain.Contains(i))
                {
                    SW_Graph.Write(i + 1);
                    SW_Graph.Write(";");
                    SW_Graph.Write("1");
                    SW_Graph.Write(";");
                    SW_Graph.Write("Undirected");
                    SW_Graph.Write(";");
                    SW_Graph.Write(0);
                    SW_Graph.Write(";");
                    SW_Graph.WriteLine();
                }
            }

            Number_Node_Txt.Text = Reminder_Feature.Count.ToString();
            Number_Edge_Txt.Text = counter.ToString();
            SW_Graph.Close();
        }

        private void Sim_Normalize()
        {
            int N = (Reminder_Feature.Count * (Reminder_Feature.Count - 1)) / 2;
            double[] New_Sim = new double[N];
            int index = 0;

            for (int i = 0; i < Reminder_Feature.Count; i++)
            {
                for (int j = i + 1; j < Reminder_Feature.Count; j++)
                {
                    New_Sim[index] = Sim[i, j];
                    index++;
                }
            }

            double Sum = 0;
            for (int i = 0; i < N; i++)
                Sum += New_Sim[i];

            double X_Bar = Sum / N;

            Sum = 0;
            for (int i = 0; i < N; i++)
                Sum += Math.Pow(New_Sim[i] - X_Bar, 2);

            double Var = Sum / (N - 1);
            Var = Math.Sqrt(Var);

            double[] x_prim = new double[N];
            for (int i = 0; i < N; i++)
                x_prim[i] = (New_Sim[i] - X_Bar) / Var;

            double[] x_hat = new double[N];
            for (int i = 0; i < N; i++)
                x_hat[i] = 1 / (1 + Math.Exp(-x_prim[i]));

            for (int i = 0; i < N; i++)
                New_Sim[i] = x_hat[i];

            index = 0;
            for (int i = 0; i < Reminder_Feature.Count; i++)
            {
                for (int j = i + 1; j < Reminder_Feature.Count; j++)
                {
                    Sim[i, j] = New_Sim[index];
                    Sim[j, i] = Sim[i, j];
                    index++;
                }
            }

        }

        private void Update_Sim()
        {
            Updated_Sim = new double[Num_Attributes, Num_Attributes];
            double Threshold=Convert.ToDouble(Edge_Thereshold_Txt.Value);
            for (int i = 0; i < Reminder_Feature.Count; i++)
            {
                for (int j = 0; j < Reminder_Feature.Count; j++)
                {
                    if (Sim[i, j] > Threshold)
                        Updated_Sim[i, j] = Sim[i, j];
                    else
                        Updated_Sim[i, j] = 0;
                }
            }
        }

        private void Power_Normalization()
        {
            double Sum = 0;
            int index = 0;
            for (int i = 0; i < Num_Attributes; i++)
            {
                if (!double.IsNaN(Power[i]) && Power[i] != 0)
                    Sum += Power[i];
                else
                    index++;
                if (Power[i] == 0)
                    Bad_Feature.Add(i);
            }

            double X_Bar = Sum / (Num_Attributes - index);

            Sum = 0;
            for (int i = 0; i < Num_Attributes; i++)
                if (!double.IsNaN(Power[i]))
                    Sum += Math.Pow(Power[i] - X_Bar, 2);

            double Var = Sum / (Num_Attributes - index - 1);
            Var = Math.Sqrt(Var);

            double[] x_prim = new double[Num_Attributes];
            for (int i = 0; i < Num_Attributes; i++)
                x_prim[i] = (Power[i] - X_Bar) / Var;

            for (int i = 0; i < Num_Attributes; i++)
                Power[i] = 1 / (1 + Math.Exp(-x_prim[i]));
        }

        private void Create_DataSet(List<string> S, int num_instance, int num_att)
        {
            string[] temp;
            string str;

            if (DataSet_Name == 0)
            {
                for (int i = 0; i < num_instance; i++)
                {
                    Data Temp_Data = new Data();
                    Temp_Data.Att = new double[num_att];
                    str = S[i];
                    temp = str.Split(',');
                    for (int j = 0; j < num_att; j++)
                    {
                        Temp_Data.Att[j] = Convert.ToDouble(temp[j]);
                    }
                    if (temp[num_att] == "R")
                        Temp_Data.Class = 0;
                    else
                        Temp_Data.Class = 1;
                    DataSet.Add(Temp_Data);
                }
            }

            if (DataSet_Name == 1)
            {
                for (int i = 0; i < num_instance; i++)
                {
                    Data Temp_Data = new Data();
                    Temp_Data.Att = new double[num_att];
                    str = S[i];
                    temp = str.Split(',');
                    for (int j = 0; j < num_att; j++)
                    {
                        Temp_Data.Att[j] = Convert.ToDouble(temp[j]);
                    }
                    if (temp[num_att] == "1")
                        Temp_Data.Class = 0;
                    else
                        Temp_Data.Class = 1;
                    DataSet.Add(Temp_Data);
                }
            }

            if (DataSet_Name == 2)
            {
                for (int i = 0; i < num_instance; i++)
                {
                    Data Temp_Data = new Data();
                    Temp_Data.Att = new double[num_att];
                    str = S[i];
                    temp = str.Split(',');
                    for (int j = 1; j < num_att + 1; j++)
                    {
                        Temp_Data.Att[j - 1] = Convert.ToDouble(temp[j]);
                    }
                    if (temp[0] == "1")
                        Temp_Data.Class = 0;
                    else
                        Temp_Data.Class = 1;
                    DataSet.Add(Temp_Data);
                }
            }

            if (DataSet_Name == 3)
            {
                for (int i = 0; i < num_instance; i++)
                {
                    Data Temp_Data = new Data();
                    Temp_Data.Att = new double[num_att];
                    str = S[i];
                    temp = str.Split(',');
                    for (int j = 1; j < num_att + 1; j++)
                    {
                        Temp_Data.Att[j - 1] = Convert.ToDouble(temp[j]);
                    }
                    if (temp[0] == "1")
                        Temp_Data.Class = 0;
                    if (temp[0] == "2")
                        Temp_Data.Class = 1;
                    if (temp[0] == "3")
                        Temp_Data.Class = 2;
                    DataSet.Add(Temp_Data);
                }
            }

            if (DataSet_Name == 4)
            {
                for (int i = 0; i < num_instance; i++)
                {
                    Data Temp_Data = new Data();
                    Temp_Data.Att = new double[num_att];
                    str = S[i];
                    temp = str.Split(',');
                    for (int j = 0; j < num_att; j++)
                    {
                        Temp_Data.Att[j] = Convert.ToDouble(temp[j]);
                    }
                    if (temp[num_att] == "g")
                        Temp_Data.Class = 0;
                    else
                        Temp_Data.Class = 1;
                    DataSet.Add(Temp_Data);
                }
            }

            if (DataSet_Name == 5)
            {
                for (int i = 0; i < num_instance; i++)
                {
                    Data Temp_Data = new Data();
                    Temp_Data.Att = new double[num_att];
                    str = S[i];
                    temp = str.Split(',');
                    for (int j = 2; j < num_att + 2; j++)
                    {
                        Temp_Data.Att[j - 2] = Convert.ToDouble(temp[j]);
                    }
                    if (temp[1] == "M")
                        Temp_Data.Class = 0;
                    else
                        Temp_Data.Class = 1;
                    DataSet.Add(Temp_Data);
                }
            }

            if (DataSet_Name == 6)
            {
                for (int i = 0; i < num_instance; i++)
                {
                    Data Temp_Data = new Data();
                    Temp_Data.Att = new double[num_att];
                    str = S[i];
                    temp = str.Split(',');
                    for (int j = 0; j < num_att; j++)
                    {
                        Temp_Data.Att[j] = Convert.ToDouble(temp[j]);
                    }
                    Temp_Data.Class = Convert.ToInt32(temp[num_att]) - 1;
                    DataSet.Add(Temp_Data);
                }
            }

            if (DataSet_Name == 8)
            {
                string[] temp2;
                string str2;
                for (int i = 0; i < num_instance; i++)
                {
                    Data Temp_Data = new Data();
                    Temp_Data.Att = new double[num_att];
                    str = S[i];
                    temp = str.Split(',');
                    for (int j = 2; j < num_att + 2; j++)
                    {
                        temp2 = temp[j].Split(':');
                        Temp_Data.Att[j - 2] = Convert.ToDouble(temp2[1]);
                    }
                    if (temp[0] == "-1.000000")
                        Temp_Data.Class = 0;
                    else
                        Temp_Data.Class = 1;
                    DataSet.Add(Temp_Data);
                }
            }

            if (DataSet_Name == 14)
            {
                for (int i = 0; i < num_instance; i++)
                {
                    Data Temp_Data = new Data();
                    Temp_Data.Att = new double[num_att];
                    str = S[i];
                    temp = str.Split(',');
                    for (int j = 0; j < num_att; j++)
                    {
                        Temp_Data.Att[j] = Convert.ToDouble(temp[j]);
                    }

                    if (temp[num_att] == "1")
                    {
                        Temp_Data.Class = 0;
                    }
                    else
                        Temp_Data.Class = 1;
                    DataSet.Add(Temp_Data);
                }
            }

            if (DataSet_Name == 12)
            {
                for (int i = 0; i < num_instance; i++)
                {
                    Data Temp_Data = new Data();
                    Temp_Data.Att = new double[num_att];
                    str = S[i];
                    temp = str.Split(',');
                    for (int j = 0; j < num_att; j++)
                    {
                        Temp_Data.Att[j] = Convert.ToDouble(temp[j]);
                    }
                    if (temp[num_att] == "0")

                        Temp_Data.Class = 0;
                    else
                        Temp_Data.Class = 1;

                    DataSet.Add(Temp_Data);
                }
            }

            if (DataSet_Name == 15)
            {
                for (int i = 0; i < num_instance; i++)
                {
                    Data Temp_Data = new Data();
                    Temp_Data.Att = new double[num_att];
                    str = S[i];
                    temp = str.Split(',');
                    for (int j = 0; j < num_att; j++)
                    {
                        Temp_Data.Att[j] = Convert.ToDouble(temp[j]);
                    }
                    
                    Temp_Data.Class = Convert.ToInt32(temp[num_att]);
                    DataSet.Add(Temp_Data);
                }
            }
        }

        private void Creat_Train_Test()
        {
            List<int> Temp = new List<int>();
            for (int i = 0; i < DataSet.Count; i++)
                Temp.Add(i);

            for (int i = 0; i < Convert.ToInt32(0.66 * DataSet.Count); i++)
            {
                int index = Rand.Next(Temp.Count);
                Train_Data.Add(DataSet[Temp[index]]);
                Temp.RemoveAt(index);
            }

            for (int i = Convert.ToInt32(0.66 * DataSet.Count); i < DataSet.Count; i++)
            {
                int index = Rand.Next(Temp.Count);
                Test_Data.Add(DataSet[Temp[index]]);
                Temp.RemoveAt(index);
            }

        }

        private void Miss_Handling()
        {
            double[] sum = new double[Num_Attributes];
            int[] num = new int[Num_Attributes];
            int[] class_num = new int[2];

            if (DataSet_Name == 1)
            {
                for (int i = 0; i < DataSet.Count; i++)
                {
                    for (int j = 0; j < Num_Attributes; j++)
                    {
                        if (DataSet[i].Att[j] != 0)
                        {
                            sum[j] += DataSet[i].Att[j];
                            num[j]++;
                        }
                    }
                }
                for (int i = 0; i < DataSet.Count; i++)
                {
                    for (int j = 0; j < Num_Attributes; j++)
                    {
                        if (DataSet[i].Att[j] == 0)
                        {
                            DataSet[i].Att[j] = sum[j] / num[j];
                        }
                    }
                }
            }

            if (DataSet_Name == 2)
            {
                for (int i = 0; i < DataSet.Count; i++)
                {
                    for (int j = 0; j < Num_Attributes; j++)
                    {
                        if (DataSet[i].Att[j] != 666)
                        {
                            sum[j] += DataSet[i].Att[j];
                            num[j]++;
                        }
                    }
                }
                for (int i = 0; i < DataSet.Count; i++)
                {
                    for (int j = 0; j < Num_Attributes; j++)
                    {
                        if (DataSet[i].Att[j] == 666)
                        {
                            DataSet[i].Att[j] = sum[j] / num[j];
                        }
                    }
                }
            }

            if (DataSet_Name == 6)
            {
                for (int i = 0; i < DataSet.Count; i++)
                {
                    for (int j = 0; j < Num_Attributes; j++)
                    {
                        if (DataSet[i].Att[j] != 666)
                        {
                            sum[j] += DataSet[i].Att[j];
                            num[j]++;
                        }
                    }
                }
                for (int i = 0; i < DataSet.Count; i++)
                {
                    for (int j = 0; j < Num_Attributes; j++)
                    {
                        if (DataSet[i].Att[j] == 666)
                        {
                            DataSet[i].Att[j] = sum[j] / num[j];
                        }
                    }
                }
            }

            if (DataSet_Name == 15)
            {
                for (int i = 0; i < DataSet.Count; i++)
                {
                    for (int j = 0; j < Num_Attributes; j++)
                    {
                        if (DataSet[i].Att[j] != 666)
                        {
                            sum[j] += DataSet[i].Att[j];
                            num[j]++;
                        }
                    }
                }
                for (int i = 0; i < DataSet.Count; i++)
                {
                    for (int j = 0; j < Num_Attributes; j++)
                    {
                        if (DataSet[i].Att[j] == 666)
                        {
                            DataSet[i].Att[j] = sum[j] / num[j];
                        }
                    }
                }
            }
        }

        private void Select_Bad_Feature()
        {
            List<int> list = new List<int>();
            for (int i = 0; i < Num_Attributes; i++)
                if (Power[i] < 0.01 || double.IsNaN(Power[i]))
                    Bad_Feature.Add(i);

        }

        private void Dimentionality_Reduction()
        {
            List<int> Good_Feature = new List<int>();
            List<double> ALL_Power = new List<double>();
            List<int> Index=new List<int>();
            ALL_Power.Clear();
            Good_Feature.Clear();
            Index.Clear();
            Bad_Feature.Clear();

            for (int i = 0; i < Num_Attributes; i++)
            {
                ALL_Power.Add(Power[i]);
                Index.Add(i);
                Bad_Feature.Add(i);
            }

            int selected = 0;
            for (int i = 0; i < 100; i++)
            {
                double Max = ALL_Power.Max();
                int Max_Index = ALL_Power.IndexOf(Max);
                selected=Index[Max_Index];
                Good_Feature.Add(selected);
                ALL_Power.RemoveAt(Max_Index);
                Index.Remove(selected);
                Bad_Feature.Remove(selected);
            }

        }

        private void Remove_Bad_Feature()
        {
            New_Train_Data.Clear();
            for (int i = 0; i < Train_Data.Count; i++)
            {
                Data Temp = new Data();
                Temp.Att = new double[Reminder_Feature.Count];
                Temp.Class = Train_Data[i].Class;
                int index = 0;
                for (int j = 0; j < Num_Attributes; j++)
                {
                    if (Reminder_Feature.Contains(j))
                    {
                        Temp.Att[index] = Train_Data[i].Att[j];
                        index++;
                    }
                }
                New_Train_Data.Add(Temp);
            }

            New_Power = new double[Reminder_Feature.Count];
            int Index = 0;
            for (int i = 0; i < Num_Attributes; i++)
            {
                if (Reminder_Feature.Contains(i))
                {
                    New_Power[Index] = Power[i];
                    Index++;
                }

            }
        }

        public void Data_Normalization()
        {
            double[] mean = new double[Num_Attributes];
            double[] var = new double[Num_Attributes];
            double[] max = new double[Num_Attributes];
            double[] min = new double[Num_Attributes];

            int Train_count = Train_Data.Count;

            for (int j = 0; j < Num_Attributes; j++)
            {
                double maxx = double.MinValue;
                double minn = double.MaxValue;
                double Sum = 0;
                for (int i = 0; i < Train_count; i++)
                {
                    if (Train_Data[i].Att[j] > maxx)
                        maxx = Train_Data[i].Att[j];
                    if (Train_Data[i].Att[j] < minn)
                        minn = Train_Data[i].Att[j];
                    Sum += Train_Data[i].Att[j];
                }
                max[j] = maxx;
                min[j] = minn;
                mean[j] = Sum / Train_count;
            }

            //for (int j = 0; j < Num_Attributes; j++)
            //{
            //    double Sum = 0;
            //    for (int i = 0; i < Train_count; i++)
            //    {
            //        Sum += Math.Pow(Train_Data[i].Att[j] - mean[j], 2);
            //    }
            //    var[j] = (Sum / (double)(Train_count - 1));
            //}

            double y = 0;
            for (int i = 0; i < Train_count; i++)
            {
                for (int j = 0; j < Num_Attributes; j++)
                {
                    Train_Data[i].Att[j] = ((Train_Data[i].Att[j] - min[j]) / (max[j] - min[j]));
                    //y = (Train_Data[i].Att[j] - mean[j]) / Math.Sqrt(var[j]);
                    //Train_Data[i].Att[j] = 1.0 / (1 + Math.Exp(-y));
                }
            }
        }

        private void Read_Comunity()
        {
            SR_Com = new StreamReader(AdressR_Com);
            string str_line;
            List<string> list = new List<string>();
            string[] temp;
            Com = new int[Reminder_Feature.Count];

            while (SR_Com.EndOfStream == false)
            {
                str_line = SR_Com.ReadLine();
                list.Add(str_line);
            }
            char ch1;
            char ch2;
            Com_Num = 0;
            for (int i = 0; i < Reminder_Feature.Count; i++)
            {
                temp = list[i + 1].Split(',');
                Com[Convert.ToInt32(temp[0]) - 1] = Convert.ToInt32(temp[1]);
                if (Convert.ToInt32(temp[1]) > Com_Num)
                    Com_Num = Convert.ToInt32(temp[1]);
            }
            Com_Num++;
            SR_Com.Close();
        }

        private void Read_Dataset_Btn_Click(object sender, EventArgs e)
        {
            DataSet.Clear();
            Train_Data.Clear();
            Test_Data.Clear();
            New_Train_Data.Clear();
            Reminder_Feature.Clear();
            Bad_Feature.Clear();

            string str_line;
            List<string> list = new List<string>();
            string Addres;

            if (DataSet_Cmb.SelectedIndex == 0)
            {
                Addres = "./Dataset/Sonar.txt";
                AdressW_After = "./Result/Sonar_After.arff";
                AdressW_Befor = "./Result/Sonar_Befor.arff";
                AdressW_Graph = "./Result/Sonar_Graph.csv";
                AdressR_Com = "./Result/Sonar_Com.csv";
                Name = "Sonar";
                DataSet_Name = 0;
                Num_Attributes = 60;
                Num_Instance = 208;
                Num_Class = 2;

                sr = new StreamReader(Addres);
                int i = 0;
                while (sr.EndOfStream == false)
                {
                    str_line = sr.ReadLine();
                    list.Add(str_line);
                    i++;
                }
                Create_DataSet(list, Num_Instance, Num_Attributes);
                Creat_Train_Test();
            }

            if (DataSet_Cmb.SelectedIndex == 1)
            {
                Addres = "./Dataset/Diabetes.txt";
                AdressW_After = "./Result/Diabetes_After.arff";
                AdressW_Befor = "./Result/Diabetes_Befor.arff";
                AdressW_Graph = "./Result/Diabetes_Graph.csv";
                AdressR_Com = "./Result/Diabetes_Com.csv";
                Adress_Sim = "./Result/Diabetes_Matrix.txt";
                Name = "Diabetes";
                DataSet_Name = 1;
                Num_Attributes = 8;
                Num_Instance = 768;
                Num_Class = 2;

                sr = new StreamReader(Addres);
                int i = 0;
                while (sr.EndOfStream == false)
                {
                    str_line = sr.ReadLine();
                    list.Add(str_line);
                    i++;
                }
                Create_DataSet(list, Num_Instance, Num_Attributes);
                Miss_Handling();
                Creat_Train_Test();
            }
            if (DataSet_Cmb.SelectedIndex == 2)
            {
                Addres = "./Dataset/Hepatitis.txt";
                AdressW_After = "./Result/Hepatitis_After.arff";
                AdressW_Befor = "./Result/Hepatitis_Befor.arff";
                AdressW_Graph = "./Result/Hepatitis_Graph.csv";
                AdressR_Com = "./Result/Hepatitis_Com.csv";
                Name = "Hepatitis";
                DataSet_Name = 2;
                Num_Attributes = 19;
                Num_Instance = 155;
                Num_Class = 2;

                sr = new StreamReader(Addres);
                int i = 0;
                while (sr.EndOfStream == false)
                {
                    str_line = sr.ReadLine();
                    list.Add(str_line);
                    i++;
                }
                Create_DataSet(list, Num_Instance, Num_Attributes);
                Miss_Handling();
                Creat_Train_Test();
            }

            if (DataSet_Cmb.SelectedIndex == 3)
            {
                Addres = "./Dataset/Wine.txt";
                AdressW_After = "./Result/Wine_After.arff";
                AdressW_Befor = "./Result/Wine_Befor.arff";
                AdressW_Graph = "./Result/Wine_Graph.csv";
                AdressR_Com = "./Result/Wine_Com.csv";
                Name = "Wine";
                DataSet_Name = 3;
                Num_Attributes = 13;
                Num_Instance = 178;
                Num_Class = 3;

                sr = new StreamReader(Addres);
                int i = 0;
                while (sr.EndOfStream == false)
                {
                    str_line = sr.ReadLine();
                    list.Add(str_line);
                    i++;
                }
                Create_DataSet(list, Num_Instance, Num_Attributes);
                Creat_Train_Test();
            }

            if (DataSet_Cmb.SelectedIndex == 4)
            {
                Addres = "./Dataset/Ionosphere.txt";
                AdressW_After = "./Result/Ionosphere_After.arff";
                AdressW_Befor = "./Result/Ionosphere_Befor.arff";
                AdressW_Graph = "./Result/Inosphere_Graph.csv";
                AdressR_Com = "./Result/Inosphere_Com.csv";
                Name = "Ionosphere";
                DataSet_Name = 4;
                Num_Attributes = 34;
                Num_Instance = 351;
                Num_Class = 2;

                sr = new StreamReader(Addres);
                int i = 0;
                while (sr.EndOfStream == false)
                {
                    str_line = sr.ReadLine();
                    list.Add(str_line);
                    i++;
                }
                Create_DataSet(list, Num_Instance, Num_Attributes);
                Creat_Train_Test();
            }

            if (DataSet_Cmb.SelectedIndex == 5)
            {
                Addres = "./Dataset/WDBC.txt";
                AdressW_After = "./Result/WDBC_After.arff";
                AdressW_Befor = "./Result/WDBC_Befor.arff";
                AdressW_Graph = "./Result/WDBC_Graph.csv";
                AdressR_Com = "./Result/WDBC_Com.csv";
                Name = "WPBC";
                DataSet_Name = 5;
                Num_Attributes = 30;
                Num_Instance = 569;
                Num_Class = 2;

                sr = new StreamReader(Addres);
                int i = 0;
                while (sr.EndOfStream == false)
                {
                    str_line = sr.ReadLine();
                    list.Add(str_line);
                    i++;
                }
                Create_DataSet(list, Num_Instance, Num_Attributes);
                Creat_Train_Test();
            }
            if (DataSet_Cmb.SelectedIndex == 6)
            {
                Addres = "./Dataset/Arrhythmia.txt";
                AdressW_After = "./Result/Arrhythmia_After.arff";
                AdressW_Befor = "./Result/Arrhythmia_Befor.arff";
                AdressW_Graph = "./Result/Arrhythmia_Graph.csv";
                AdressR_Com = "./Result/Arrhythmia_Com.csv";
                Name = "Arrhythmia";
                DataSet_Name = 6;
                Num_Attributes = 279;
                Num_Instance = 452;
                Num_Class = 16;

                sr = new StreamReader(Addres);
                int i = 0;
                while (sr.EndOfStream == false)
                {
                    str_line = sr.ReadLine();
                    list.Add(str_line);
                    i++;
                }
                Create_DataSet(list, Num_Instance, Num_Attributes);
                Miss_Handling();
                Creat_Train_Test();
            }

            if (DataSet_Cmb.SelectedIndex == 7)
            {
                string[] temp;
                string str;

                string Adress_Train = "./Dataset/Madelon_Train.txt";
                string Adress_Valid = "./Dataset/Madelon_Valid.txt";
                string Adress_Train_Label = "./Dataset/Madelon_Train_Label.txt";
                string Adress_Valid_Label = "./Dataset/Madelon_Valid_Label.txt";
                Adress_Sim = "./Result/Madelon_Sim.txt";
                Adress_Power = "./Result/Madelon_Power.txt";

                AdressW_After = "./Result/Madelon_After.arff";
                AdressW_Befor = "./Result/Madelon_Befor.arff";
                AdressW_Graph = "./Result/Madelon_Graph.csv";
                AdressR_Com = "./Result/Madelon_Com.csv";
                Name = "Madelon";
                DataSet_Name = 7;
                Num_Attributes = 500;
                Num_Instance = 2600;
                int Train_Number = 2000;
                int Test_Number = 600;
                Num_Class = 2;

                StreamReader Sr_Train = new StreamReader(Adress_Train);
                StreamReader Sr_Train_Label = new StreamReader(Adress_Train_Label);
                StreamReader Sr_Valid = new StreamReader(Adress_Valid);
                StreamReader Sr_Valid_Label = new StreamReader(Adress_Valid_Label);

                while (Sr_Train.EndOfStream == false)
                {
                    str_line = Sr_Train.ReadLine();
                    list.Add(str_line);
                }
                for (int i = 0; i < Train_Number; i++)
                {
                    Data Temp_Data = new Data();
                    Temp_Data.Att = new double[Num_Attributes];
                    str = list[i];
                    temp = str.Split(' ');
                    for (int j = 0; j < Num_Attributes; j++)
                    {
                        Temp_Data.Att[j] = Convert.ToDouble(temp[j]);
                    }
                    Train_Data.Add(Temp_Data);
                }

                list.Clear();
                while (Sr_Train_Label.EndOfStream == false)
                {
                    str_line = Sr_Train_Label.ReadLine();
                    list.Add(str_line);
                }
                for (int i = 0; i < Train_Number; i++)
                {
                    str = list[i];
                    if (Convert.ToInt32(str) == 1)
                        Train_Data[i].Class = 1;
                    else
                        Train_Data[i].Class = 0;
                }

                list.Clear();
                while (Sr_Valid.EndOfStream == false)
                {
                    str_line = Sr_Valid.ReadLine();
                    list.Add(str_line);
                }
                for (int i = 0; i < Test_Number; i++)
                {
                    Data Temp_Data = new Data();
                    Temp_Data.Att = new double[Num_Attributes];
                    str = list[i];
                    temp = str.Split(' ');
                    for (int j = 0; j < Num_Attributes; j++)
                    {
                        Temp_Data.Att[j] = Convert.ToDouble(temp[j]);
                    }
                    Test_Data.Add(Temp_Data);
                }

                list.Clear();
                while (Sr_Valid_Label.EndOfStream == false)
                {
                    str_line = Sr_Valid_Label.ReadLine();
                    list.Add(str_line);
                }
                for (int i = 0; i < Test_Number; i++)
                {
                    str = list[i];
                    if (Convert.ToInt32(str) == 1)
                        Test_Data[i].Class = 1;
                    else
                        Test_Data[i].Class = 0;
                }
            }

            if (DataSet_Cmb.SelectedIndex == 8)
            {
                Addres = "./Dataset/Colon.txt";
                AdressW_After = "./Result/Colon_After.arff";
                AdressW_Befor = "./Result/Colon_Befor.arff";
                AdressW_Graph = "./Result/Colon_Graph.csv";
                AdressR_Com = "./Result/Colon_Com.csv";
                Name = "Colon";
                DataSet_Name = 8;
                Num_Attributes = 2000;
                Num_Instance = 62;
                Num_Class = 2;

                sr = new StreamReader(Addres);
                int i = 0;
                while (sr.EndOfStream == false)
                {
                    str_line = sr.ReadLine();
                    list.Add(str_line);
                    i++;
                }
                Create_DataSet(list, Num_Instance, Num_Attributes);
                Creat_Train_Test();
            }

            if (DataSet_Cmb.SelectedIndex == 9)
            {
                string Addres1 = "./Dataset/Mfeat1.txt";
                string Addres2 = "./Dataset/Mfeat2.txt";
                string Addres3 = "./Dataset/Mfeat3.txt";
                string Addres4 = "./Dataset/Mfeat4.txt";
                string Addres5 = "./Dataset/Mfeat5.txt";
                string Addres6 = "./Dataset/Mfeat6.txt";

                AdressW_After = "./Result/Mfeat_After.arff";
                AdressW_Befor = "./Result/Mfeat_Befor.arff";
                AdressW_Graph = "./Result/Mfeat_Graph.csv";
                AdressR_Com = "./Result/Mfeat_Com.csv";
                Name = "Mfeat";
                DataSet_Name = 9;
                Num_Attributes = 649;
                Num_Instance = 2000;
                Num_Class = 10;

                string[] temp;
                string str;

                StreamReader Sr1 = new StreamReader(Addres1);
                StreamReader Sr2 = new StreamReader(Addres2);
                StreamReader Sr3 = new StreamReader(Addres3);
                StreamReader Sr4 = new StreamReader(Addres4);
                StreamReader Sr5 = new StreamReader(Addres5);
                StreamReader Sr6 = new StreamReader(Addres6);

                while (Sr1.EndOfStream == false)
                {
                    str_line = Sr1.ReadLine();
                    list.Add(str_line);
                }
                for (int i = 0; i < Num_Instance; i++)
                {
                    Data Temp_Data = new Data();
                    Temp_Data.Att = new double[Num_Attributes];
                    str = list[i];
                    temp = str.Split(' ');
                    for (int j = 0; j < 76; j++)
                    {
                        Temp_Data.Att[j] = Convert.ToDouble(temp[j + 1]);
                    }
                    DataSet.Add(Temp_Data);
                }

                list.Clear();
                while (Sr2.EndOfStream == false)
                {
                    str_line = Sr2.ReadLine();
                    list.Add(str_line);
                }
                for (int i = 0; i < Num_Instance; i++)
                {
                    str = list[i];
                    temp = str.Split(' ');
                    for (int j = 0; j < 216; j++)
                    {
                        DataSet[i].Att[j + 76] = Convert.ToDouble(temp[j + 1]);
                    }
                }

                list.Clear();
                while (Sr3.EndOfStream == false)
                {
                    str_line = Sr3.ReadLine();
                    list.Add(str_line);
                }
                for (int i = 0; i < Num_Instance; i++)
                {
                    str = list[i];
                    temp = str.Split(' ');
                    for (int j = 0; j < 64; j++)
                    {
                        DataSet[i].Att[j + 76 + 216] = Convert.ToDouble(temp[j + 1]);
                    }
                }

                list.Clear();
                while (Sr4.EndOfStream == false)
                {
                    str_line = Sr4.ReadLine();
                    list.Add(str_line);
                }
                for (int i = 0; i < Num_Instance; i++)
                {
                    str = list[i];
                    temp = str.Split(' ');
                    for (int j = 0; j < 240; j++)
                    {
                        DataSet[i].Att[j + 76 + 216 + 64] = Convert.ToDouble(temp[j + 1]);
                    }
                }

                list.Clear();
                while (Sr5.EndOfStream == false)
                {
                    str_line = Sr5.ReadLine();
                    list.Add(str_line);
                }
                for (int i = 0; i < Num_Instance; i++)
                {
                    str = list[i];
                    temp = str.Split(' ');
                    for (int j = 0; j < 47; j++)
                    {
                        DataSet[i].Att[j + 76 + 216 + 64 + 240] = Convert.ToDouble(temp[j + 1]);
                    }
                }

                list.Clear();
                while (Sr6.EndOfStream == false)
                {
                    str_line = Sr6.ReadLine();
                    list.Add(str_line);
                }
                for (int i = 0; i < Num_Instance; i++)
                {
                    str = list[i];
                    temp = str.Split(' ');
                    for (int j = 0; j < 6; j++)
                    {
                        DataSet[i].Att[j + 76 + 216 + 64 + 240 + 47] = Convert.ToDouble(temp[j + 1]);
                    }
                }

                for (int i = 0; i < 200; i++)
                    DataSet[i].Class = 0;

                for (int i = 0; i < 200; i++)
                    DataSet[i + 200].Class = 1;

                for (int i = 0; i < 200; i++)
                    DataSet[i + 400].Class = 2;

                for (int i = 0; i < 200; i++)
                    DataSet[i + 600].Class = 3;

                for (int i = 0; i < 200; i++)
                    DataSet[i + 800].Class = 4;

                for (int i = 0; i < 200; i++)
                    DataSet[i + 1000].Class = 5;

                for (int i = 0; i < 200; i++)
                    DataSet[i + 1200].Class = 6;

                for (int i = 0; i < 200; i++)
                    DataSet[i + 1400].Class = 7;

                for (int i = 0; i < 200; i++)
                    DataSet[i + 1600].Class = 8;

                for (int i = 0; i < 200; i++)
                    DataSet[i + 1800].Class = 9;

                Creat_Train_Test();
            }

            if (DataSet_Cmb.SelectedIndex == 10)
            {
                string[] temp;
                string str;

                string Adress_Train = "./Dataset/Arcene_Train.txt";
                string Adress_Valid = "./Dataset/Arcene_Valid.txt";
                string Adress_Train_Label = "./Dataset/Arcene_Train_Label.txt";
                string Adress_Valid_Label = "./Dataset/Arcene_Valid_Label.txt";

                AdressW_After = "./Result/Arcene_After.arff";
                AdressW_Befor = "./Result/Arcene_Befor.arff";
                AdressW_Graph = "./Result/Arcene_Graph.csv";
                AdressR_Com = "./Result/Arcene_Com.csv";
                Adress_Sim = "./Result/Arcene_Sim.txt";
                Adress_Power = "./Result/Arcene_Power.txt";

                Name = "Arcene";
                DataSet_Name = 10;
                Num_Attributes = 10000;
                Num_Instance = 200;
                int Train_Number = 100;
                int Test_Number = 100;
                Num_Class = 2;

                StreamReader Sr_Train = new StreamReader(Adress_Train);
                StreamReader Sr_Train_Label = new StreamReader(Adress_Train_Label);
                StreamReader Sr_Valid = new StreamReader(Adress_Valid);
                StreamReader Sr_Valid_Label = new StreamReader(Adress_Valid_Label);

                while (Sr_Train.EndOfStream == false)
                {
                    str_line = Sr_Train.ReadLine();
                    list.Add(str_line);
                }
                for (int i = 0; i < Train_Number; i++)
                {
                    Data Temp_Data = new Data();
                    Temp_Data.Att = new double[Num_Attributes];
                    str = list[i];
                    temp = str.Split(' ');
                    for (int j = 0; j < Num_Attributes; j++)
                    {
                        Temp_Data.Att[j] = Convert.ToDouble(temp[j]);
                    }
                    Train_Data.Add(Temp_Data);
                }

                list.Clear();
                while (Sr_Train_Label.EndOfStream == false)
                {
                    str_line = Sr_Train_Label.ReadLine();
                    list.Add(str_line);
                }
                for (int i = 0; i < Train_Number; i++)
                {
                    str = list[i];
                    if (Convert.ToInt32(str) == 1)
                        Train_Data[i].Class = 1;
                    else
                        Train_Data[i].Class = 0;
                }

                list.Clear();
                while (Sr_Valid.EndOfStream == false)
                {
                    str_line = Sr_Valid.ReadLine();
                    list.Add(str_line);
                }
                for (int i = 0; i < Test_Number; i++)
                {
                    Data Temp_Data = new Data();
                    Temp_Data.Att = new double[Num_Attributes];
                    str = list[i];
                    temp = str.Split(' ');
                    for (int j = 0; j < Num_Attributes; j++)
                    {
                        Temp_Data.Att[j] = Convert.ToDouble(temp[j]);
                    }
                    Test_Data.Add(Temp_Data);
                }

                list.Clear();
                while (Sr_Valid_Label.EndOfStream == false)
                {
                    str_line = Sr_Valid_Label.ReadLine();
                    list.Add(str_line);
                }
                for (int i = 0; i < Test_Number; i++)
                {
                    str = list[i];
                    if (Convert.ToInt32(str) == 1)
                        Test_Data[i].Class = 1;
                    else
                        Test_Data[i].Class = 0;
                }
            }


            if (DataSet_Cmb.SelectedIndex == 11)
            {
                string[] temp;
                string str;

                string Adress_Train = "./Dataset/Isolet_Train.txt";
                string Adress_Valid = "./Dataset/Isolet_Valid.txt";

                AdressW_After = "./Result/Isolet_After.arff";
                AdressW_Befor = "./Result/Isolet_Befor.arff";
                AdressW_Graph = "./Result/Isolet_Graph.csv";
                AdressR_Com = "./Result/Isolet_Com.csv";
                Adress_Sim = "./Result/Isolet_Sim.txt";
                Adress_Power = "./Result/Isolet_Power.txt";

                Name = "Isolet";
                DataSet_Name = 11;
                Num_Attributes = 617;
                Num_Instance = 7797;
                int Train_Number = 6238;
                int Test_Number = 1559;
                Num_Class = 26;

                StreamReader Sr_Train = new StreamReader(Adress_Train);
                StreamReader Sr_Valid = new StreamReader(Adress_Valid);

                while (Sr_Train.EndOfStream == false)
                {
                    str_line = Sr_Train.ReadLine();
                    list.Add(str_line);
                }
                for (int i = 0; i < Train_Number; i++)
                {
                    Data Temp_Data = new Data();
                    Temp_Data.Att = new double[Num_Attributes];
                    str = list[i];
                    temp = str.Split(',');
                    for (int j = 0; j < Num_Attributes; j++)
                    {
                        Temp_Data.Att[j] = Convert.ToDouble(temp[j]);
                    }
                    Temp_Data.Class = Convert.ToInt32(temp[Num_Attributes]) - 1;
                    Train_Data.Add(Temp_Data);
                }


                list.Clear();
                while (Sr_Valid.EndOfStream == false)
                {
                    str_line = Sr_Valid.ReadLine();
                    list.Add(str_line);
                }
                for (int i = 0; i < Test_Number; i++)
                {
                    Data Temp_Data = new Data();
                    Temp_Data.Att = new double[Num_Attributes];
                    str = list[i];
                    temp = str.Split(',');
                    for (int j = 0; j < Num_Attributes; j++)
                    {
                        Temp_Data.Att[j] = Convert.ToDouble(temp[j]);
                    }
                    Temp_Data.Class = Convert.ToInt32(temp[Num_Attributes]) - 1;
                    Test_Data.Add(Temp_Data);
                }
            }

            if (DataSet_Cmb.SelectedIndex == 12)
            {
                Addres = "./Dataset/Leukemia.txt";
                AdressW_After = "./Result/Leukemia_After.arff";
                AdressW_Befor = "./Result/Leukemia_Befor.arff";
                AdressW_Graph = "./Result/Leukemia_Graph.csv";
                AdressR_Com = "./Result/Leukemia_Com.csv";
                Name = "Leukemia";
                DataSet_Name = 12;
                Num_Attributes = 7129;
                Num_Instance = 72;
                Num_Class = 2;

                sr = new StreamReader(Addres);
                int i = 0;
                while (sr.EndOfStream == false)
                {
                    str_line = sr.ReadLine();
                    list.Add(str_line);
                    i++;
                }
                Create_DataSet(list, Num_Instance, Num_Attributes);
                Creat_Train_Test();

            }

            if (DataSet_Cmb.SelectedIndex == 13)
            {
                string[] temp;
                string str;

                string Adress_Train = "./Dataset/Gisette_Train.txt";
                string Adress_Valid = "./Dataset/Gisette_Valid.txt";
                string Adress_Train_Label = "./Dataset/Gisette_Train_Label.txt";
                string Adress_Valid_Label = "./Dataset/Gisette_Valid_Label.txt";

                AdressW_After = "./Result/Gisette_After.arff";
                AdressW_Befor = "./Result/Gisette_Befor.arff";
                AdressW_Graph = "./Result/Gisette_Graph.csv";
                AdressR_Com = "./Result/Gisette_Com.csv";
                Adress_Sim = "./Result/Gisette_Sim.txt";
                Adress_Power = "./Result/Gisette_Power.txt";

                Name = "Gisette";
                DataSet_Name = 12;
                Num_Attributes = 5000;
                Num_Instance = 7000;
                int Train_Number = 6000;
                int Test_Number = 1000;
                Num_Class = 2;

                StreamReader Sr_Train = new StreamReader(Adress_Train);
                StreamReader Sr_Train_Label = new StreamReader(Adress_Train_Label);
                StreamReader Sr_Valid = new StreamReader(Adress_Valid);
                StreamReader Sr_Valid_Label = new StreamReader(Adress_Valid_Label);

                while (Sr_Train.EndOfStream == false)
                {
                    str_line = Sr_Train.ReadLine();
                    list.Add(str_line);
                }
                for (int i = 0; i < Train_Number; i++)
                {
                    Data Temp_Data = new Data();
                    Temp_Data.Att = new double[Num_Attributes];
                    str = list[i];
                    temp = str.Split(' ');
                    for (int j = 0; j < Num_Attributes; j++)
                    {
                        Temp_Data.Att[j] = Convert.ToDouble(temp[j]);
                    }
                    Train_Data.Add(Temp_Data);
                }

                list.Clear();
                while (Sr_Train_Label.EndOfStream == false)
                {
                    str_line = Sr_Train_Label.ReadLine();
                    list.Add(str_line);
                }
                for (int i = 0; i < Train_Number; i++)
                {
                    str = list[i];
                    if (Convert.ToInt32(str) == 1)
                        Train_Data[i].Class = 1;
                    else
                        Train_Data[i].Class = 0;
                }

                list.Clear();
                while (Sr_Valid.EndOfStream == false)
                {
                    str_line = Sr_Valid.ReadLine();
                    list.Add(str_line);
                }
                for (int i = 0; i < Test_Number; i++)
                {
                    Data Temp_Data = new Data();
                    Temp_Data.Att = new double[Num_Attributes];
                    str = list[i];
                    temp = str.Split(' ');
                    for (int j = 0; j < Num_Attributes; j++)
                    {
                        Temp_Data.Att[j] = Convert.ToDouble(temp[j]);
                    }
                    Test_Data.Add(Temp_Data);
                }

                list.Clear();
                while (Sr_Valid_Label.EndOfStream == false)
                {
                    str_line = Sr_Valid_Label.ReadLine();
                    list.Add(str_line);
                }
                for (int i = 0; i < Test_Number; i++)
                {
                    str = list[i];
                    if (Convert.ToInt32(str) == 1)
                        Test_Data[i].Class = 1;
                    else
                        Test_Data[i].Class = 0;
                }
            }

            if (DataSet_Cmb.SelectedIndex == 14)
            {
                Addres = "./Dataset/SpamBase.txt";
                AdressW_After = "./Result/SpamBase_After.arff";
                AdressW_Befor = "./Result/SpamBase_Befor.arff";
                AdressW_Graph = "./Result/SpamBase_Graph.csv";
                AdressR_Com = "./Result/SpamBase_Com.csv";
                Name = "SpamBase";
                DataSet_Name = 14;
                Num_Attributes = 57;
                Num_Instance = 4601;
                Num_Class = 2;

                sr = new StreamReader(Addres);
                int i = 0;
                while (sr.EndOfStream == false)
                {
                    str_line = sr.ReadLine();
                    list.Add(str_line);
                    i++;
                }
                Create_DataSet(list, Num_Instance, Num_Attributes);
                Creat_Train_Test();
            }

            if (DataSet_Cmb.SelectedIndex == 15)
            {
                Addres = "./Dataset/Lymphoma.txt";
                AdressW_After = "./Result/Lymphoma_After.arff";
                AdressW_Befor = "./Result/Lymphoma_Befor.arff";
                AdressW_Graph = "./Result/Lymphoma_Graph.csv";
                AdressR_Com = "./Result/Lymphoma_Com.csv";
                Name = "Lymphoma";
                DataSet_Name = 15;
                Num_Attributes = 4026;
                Num_Instance = 96;
                Num_Class = 9;

                sr = new StreamReader(Addres);
                int i = 0;
                while (sr.EndOfStream == false)
                {
                    str_line = sr.ReadLine();
                    list.Add(str_line);
                    i++;
                }
                Create_DataSet(list, Num_Instance, Num_Attributes);
                Miss_Handling();
                Creat_Train_Test();
            }
            if (Normalized_Check.Checked == true)
                Data_Normalization();

            Read_Dataset = true;
            Start_Btn.Enabled = true;
        }

        private void Main_Load(object sender, EventArgs e)
        {
            DataSet_Cmb.SelectedIndex = 2;
            Method_Cmb.SelectedIndex = 0;
        }

        private void Sim_Calc_Btn_Click(object sender, EventArgs e)
        {
            Relevant R = new Relevant(Train_Data);
            Reminder_Feature.Clear();
            
            DateTime Start_Time = DateTime.Now;
            TimeSpan End;
            int ms = 0;
            int s = 0;
            int min = 0;

            if (Method_Cmb.SelectedIndex == 4 )
            {
                Power = R.Run_Term_Variance();
                Power_Normalization();
                Select_Bad_Feature();
                for (int i = 0; i < Num_Attributes; i++)
                {
                    if (!Bad_Feature.Contains(i))
                        Reminder_Feature.Add(i);
                }
                Remove_Bad_Feature();

                Sim = new double[Reminder_Feature.Count, Reminder_Feature.Count];
                
                Similarity similarity = new Similarity(New_Train_Data, 1);
                Sim = similarity.Calc_Sim();

                End = DateTime.Now.Subtract(Start_Time);
                ms = End.Milliseconds;
                s = End.Seconds;
                min = End.Minutes;
            }

            if (Method_Cmb.SelectedIndex == 5)
            {
                Power = R.Run_Fisher_Score(Num_Class);
                Power_Normalization();
                Select_Bad_Feature();
                for (int i = 0; i < Num_Attributes; i++)
                {
                    if (!Bad_Feature.Contains(i))
                        Reminder_Feature.Add(i);
                }
                Remove_Bad_Feature();

                Sim = new double[Reminder_Feature.Count, Reminder_Feature.Count];
                Similarity similarity = new Similarity(New_Train_Data, 0);
                Sim = similarity.Calc_Sim();
                Sim_Normalize();

                End = DateTime.Now.Subtract(Start_Time);
                ms = End.Milliseconds;
                s = End.Seconds;
                min = End.Minutes;

                Write_Graph();
                Read_Com_Btn.Enabled = true;
            }

            if (Method_Cmb.SelectedIndex == 6)
            {
                Power = R.Run_Term_Variance();
                Power_Normalization();
                
                Select_Bad_Feature();
                for (int i = 0; i < Num_Attributes; i++)
                {
                    if (!Bad_Feature.Contains(i))
                        Reminder_Feature.Add(i);
                }
                Remove_Bad_Feature();

                Sim = new double[Reminder_Feature.Count, Reminder_Feature.Count];

                Similarity similarity = new Similarity(New_Train_Data, 0);
                Sim = similarity.Calc_Sim();
                Sim_Normalize();

                End = DateTime.Now.Subtract(Start_Time);
                ms = End.Milliseconds;
                s = End.Seconds;
                min = End.Minutes;
               
                Write_Graph();
                Update_Sim();
                Read_Com_Btn.Enabled = true;
            }

            if (Method_Cmb.SelectedIndex == 7)
            {
                Power = R.Run_Fisher_Score(Num_Class);
                Power_Normalization();

                Select_Bad_Feature();
                for (int i = 0; i < Num_Attributes; i++)
                {
                    if (!Bad_Feature.Contains(i))
                        Reminder_Feature.Add(i);
                }
                Remove_Bad_Feature();

                Sim = new double[Reminder_Feature.Count, Reminder_Feature.Count];

                Similarity similarity = new Similarity(New_Train_Data, 0);
                Sim = similarity.Calc_Sim();
                Sim_Normalize();

                End = DateTime.Now.Subtract(Start_Time);
                ms = End.Milliseconds;
                s = End.Seconds;
                min = End.Minutes;

                Write_Graph();
                Update_Sim();
                Read_Com_Btn.Enabled = true;
            }

            if (Method_Cmb.SelectedIndex == 8)
            {
                Power = R.Run_Fisher_Score(Num_Class);
                Power_Normalization();
                if (Num_Attributes > 100)
                    Dimentionality_Reduction();
                else
                    Select_Bad_Feature();


                for (int i = 0; i < Num_Attributes; i++)
                {
                    if (!Bad_Feature.Contains(i))
                        Reminder_Feature.Add(i);
                }
                Remove_Bad_Feature();

                Sim = new double[Reminder_Feature.Count, Reminder_Feature.Count];

                Similarity similarity = new Similarity(New_Train_Data, 0);
                Sim = similarity.Calc_Sim();
                Sim_Normalize();

                End = DateTime.Now.Subtract(Start_Time);
                ms = End.Milliseconds;
                s = End.Seconds;
                min = End.Minutes;

                Write_Graph();
                Update_Sim();
                Read_Com_Btn.Enabled = true;
            }

            if (Method_Cmb.SelectedIndex == 9)
            {
                Power = R.Run_Fisher_Score(Num_Class);
                Power_Normalization();

                if (Num_Attributes > 100)
                    Dimentionality_Reduction();
                else
                    Select_Bad_Feature();

                for (int i = 0; i < Num_Attributes; i++)
                {
                    if (!Bad_Feature.Contains(i))
                        Reminder_Feature.Add(i);
                }
                Remove_Bad_Feature();

                Sim = new double[Reminder_Feature.Count, Reminder_Feature.Count];

                Similarity similarity = new Similarity(New_Train_Data, 0);
                Sim = similarity.Calc_Sim();
                Sim_Normalize();

                End = DateTime.Now.Subtract(Start_Time);
                ms = End.Milliseconds;
                s = End.Seconds;
                min = End.Minutes;

                Write_Graph();
                Update_Sim();
                Read_Com_Btn.Enabled = true;
            }

            Sim_ms_Time_Txt.Text = ms.ToString();
            Sim_s_Time_Txt.Text = s.ToString();
            Sim_min_Time_Txt.Text = min.ToString();


        }

        private void Method_Cmb_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Read_Dataset)
            {
                if (Method_Cmb.SelectedIndex == 4 || Method_Cmb.SelectedIndex == 5 || Method_Cmb.SelectedIndex == 6 || Method_Cmb.SelectedIndex == 7 || Method_Cmb.SelectedIndex == 8 || Method_Cmb.SelectedIndex == 9)
                    Sim_Calc_Btn.Enabled = true;
                else
                    Sim_Calc_Btn.Enabled = false;

                if (Method_Cmb.SelectedIndex == 0 || Method_Cmb.SelectedIndex == 1 || Method_Cmb.SelectedIndex == 2 || Method_Cmb.SelectedIndex == 3)
                    Start_Btn.Enabled = true;
            }
        }

        private void Read_Com_Btn_Click(object sender, EventArgs e)
        {
            Read_Comunity();
            Start_Btn.Enabled = true;
        }

        private void Start_Btn_Click(object sender, EventArgs e)
        {
            int Iteration = Convert.ToInt32(Iteration_Txt.Value);
            int Ant_Num = Convert.ToInt32(Ant_Number_Txt.Value);
            int m = Convert.ToInt32(Selected_Feature_Num_Txt.Value);
            int K = Convert.ToInt32(K_Txt.Value);
            int Cycle_Lenght = Convert.ToInt32(Cycle_Lenght_Txt.Value);
            double Com_Theshold = Convert.ToDouble(Com_Thereshold_Txt.Value);
            double Graph_Threshold = Convert.ToDouble(Graph_Threshold_Txt.Value);
            double q = 0.7;

            DateTime Start_Time = DateTime.Now;

            if (Method_Cmb.SelectedIndex == 0)
            {
                Relevant R = new Relevant(Train_Data);
                R.Run_Term_Variance();
                Result = R.Select_Feature(m);
                for (int i = 0; i < Num_Attributes; i++)
                {
                    Reminder_Feature.Add(i);
                }
            }

            if (Method_Cmb.SelectedIndex == 1)
            {
                Relevant R = new Relevant(Train_Data);
                R.Run_Laplacian_Scor();
                Result = R.Select_Feature(m);

                for (int i = 0; i < Num_Attributes; i++)
                {
                    Reminder_Feature.Add(i);
                }
            }

            if (Method_Cmb.SelectedIndex == 2)
            {
                Relevant R = new Relevant(Train_Data);
                R.Run_Fisher_Score(Num_Class);
                Result = R.Select_Feature(m);

                for (int i = 0; i < Num_Attributes; i++)
                {
                    Reminder_Feature.Add(i);
                }
            }

            if (Method_Cmb.SelectedIndex == 3)
            {
                Relevant R = new Relevant(Train_Data);
                R.Run_Constraint_Score(Num_Class);
                Result = R.Select_Feature(m);

                for (int i = 0; i < Num_Attributes; i++)
                {
                    Reminder_Feature.Add(i);
                }
            }

            if (Method_Cmb.SelectedIndex == 4)
            {
                double P = 0.2;
                Ant_Colony Ant = new Ant_Colony(Sim, New_Train_Data, Com, Com_Num, New_Power, Iteration, Ant_Num, Cycle_Lenght, m, P, q, Com_Theshold);
                Result = Ant.Run_USFSACO();
            }

            if (Method_Cmb.SelectedIndex == 5)
            {
                double P = 0.7;
                Ant_Colony Ant = new Ant_Colony(Sim, New_Train_Data, Com, Com_Num, New_Power, Iteration, Ant_Num, Cycle_Lenght, m, P, q, Com_Theshold);
                Result = Ant.Run_Com_Com();
            }

            if (Method_Cmb.SelectedIndex == 6)
            {
                Graph graph = new Graph(Updated_Sim, New_Power, Com, Com_Num, K, Graph_Threshold);
                Result = graph.Run_Graph();
            }


            if (Method_Cmb.SelectedIndex == 7)
            {
                Graph graph = new Graph(Updated_Sim, New_Power, Com, Com_Num, K, Graph_Threshold);
                Result = graph.Run_Graph();;
            }

            if (Method_Cmb.SelectedIndex == 8)
            {
                Genetic GA = new Genetic(Iteration, 0.8, 0.08, Ant_Num, 0, Num_Class, Com_Num, 3, New_Train_Data, Com, Sim, New_Power, true);
                Result = GA.Run_GA();
            }

            if (Method_Cmb.SelectedIndex == 9)
            {

                Genetic GA = new Genetic(Iteration, 0.8, 0.08,Ant_Num , 0, Num_Class, Com_Num, 3, Train_Data, Com, Sim, New_Power, false);
                Result = GA.Run_GA();
            }

            TimeSpan End = DateTime.Now.Subtract(Start_Time);
            int ms = End.Milliseconds;
            int s = End.Seconds;
            int min = End.Minutes;
            Run_ms_Time_Txt.Text = ms.ToString();
            Run_s_Time_Txt.Text = s.ToString();
            Run_min_Time_Txt.Text = min.ToString();

            if (Method_Cmb.SelectedIndex == 0 || Method_Cmb.SelectedIndex == 1 || Method_Cmb.SelectedIndex == 2 || Method_Cmb.SelectedIndex == 3)
            {
                Sim_ms_Time_Txt.Text = "0";
                Sim_s_Time_Txt.Text = "0";
                Sim_min_Time_Txt.Text = "0";
            }
            int Sum_Time_ms = Convert.ToInt32(Sim_ms_Time_Txt.Text) + Convert.ToInt32(Run_ms_Time_Txt.Text);
            int Sum_Time_s = Convert.ToInt32(Sim_s_Time_Txt.Text) + Convert.ToInt32(Run_s_Time_Txt.Text);
            int Sum_Time_min = Convert.ToInt32(Sim_min_Time_Txt.Text) + Convert.ToInt32(Run_min_Time_Txt.Text);

            int Sum_Tim = Sum_Time_ms + 1000 * Sum_Time_s + 60000 * Sum_Time_min;
            Sum.Text = Sum_Tim.ToString();
            Do_Writting();
        }

    }
}
