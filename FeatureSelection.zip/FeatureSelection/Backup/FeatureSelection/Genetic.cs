﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FeatureSelection
{
    class Genetic
    {
        private Random random = new Random();
        private int Num_Feature;
        private int Num_Class;
        int Elite;
        double Crossover;
        double Mutation;
        int Population;
        int Iteration;
        List<Data> All_Data;
        List<Data> Train_Data;
        List<Data> Valid_Data;
        int Num_Com;
        int Best_Index;
        double totalFitness = 0;

        List<Chromosome> offspring = new List<Chromosome>();
        List<Chromosome> Parent = new List<Chromosome>();
        double[,] Sim;
        double[] Power;
        int[] Com;
        int Omega;
        List<int>[] Com_List;
        Criterion criteration;
        bool Repair_Random;

        public Genetic(int it, double Crs, double Mut, int pop, int E, int num_class, int num_com, int omega, List<Data> all_data, int[] com, double[,] S, double[] power, bool repair_random)
        {
            Iteration = it;
            Crossover = Crs;
            Mutation = Mut;
            Population = pop;
            Num_Class = num_class;
            Num_Com = num_com;
            Elite = E;
            Omega = omega;
            All_Data = all_data;
            Repair_Random = repair_random; ;

            Sim = S;
            Power = power;
            Com = com;
            Com_List = new List<int>[Num_Com];
            Num_Feature = all_data[0].Att.Length;
            Set_Com_List();
            Set_Train_Valid();


        }

        public List<int> Run_GA()
        {
            List<Chromosome> Result = new List<Chromosome>();
            Result.Clear();
            Chromosome ch = new Chromosome();
            List<Chromosome> initPopulation = new List<Chromosome>();
            Init();
            CalcFitness();

            for (int generation = 0; generation < Iteration; generation++)
            {
                Pre_RuletteWheel();
                Cross(Crossover);
                Mutate(Mutation);
                Calc_Clusters();
                if (Repair_Random)
                    Repar_Operation_Random();
                else
                    Repar_Operation_Score();
                CalcFitness();
                Result.Add(Parent[Best_Index]);
            }
            Chromosome Best_Chromosome = Best(Result);

            return Final_Select(Best_Chromosome);
        }

        private void Init()
        {
            int index;
            int Selected;
            Parent.Clear();
            for (int ii = 0; ii < Population; ii++)
            {
                Chromosome ch = new Chromosome();
                ch.genes = new int[Num_Feature];
                ch.Cluster = new List<int>[Num_Com];

                for (int i = 0; i < Num_Com; i++)
                {
                    List<int> l = new List<int>();
                    l.Clear();

                    ch.Cluster[i] = new List<int>();
                    for (int j = 0; j < Com_List[i].Count; j++)
                        l.Add(Com_List[i][j]);

                    for (int k = 0; k < Omega; k++)
                    {
                        index = random.Next(l.Count);
                        Selected = l[index];
                        ch.genes[Selected] = 1;
                        ch.Cluster[i].Add(Selected);
                        l.Remove(Selected);
                    }
                }
                Parent.Add(ch);
            }
        }

        private void Pre_RuletteWheel()
        {
            double currentTotalFitness = 0;
            for (int i = 0; i < Parent.Count; i++)
            {
                currentTotalFitness += Parent[i].Fitness;
                Parent[i].cumulative_fitness = currentTotalFitness / (double)totalFitness;
            }
        }

        private int AssayRuletteWheel()
        {
            double probability = random.NextDouble();
            int i = 0;
            for (i = 0; i < Parent.Count; i++)
            {
                if (Parent[i].cumulative_fitness > probability)
                    break;

            }
            return i;
        }

        private void Cross(double probability)
        {
            offspring.Clear();
            List<Chromosome> Sorted_list = new List<Chromosome>();
            Random Rand = new Random();

            if (Elite == 1)
            {
                offspring.Add(Parent[Best_Index]);
            }

            for (int i = 0; i < Population; i = i + 2)
            {
                int ParentX_Index = AssayRuletteWheel();
                int ParentY_Index = AssayRuletteWheel();
                Chromosome ParentX = new Chromosome();
                Chromosome ParentY = new Chromosome();
                ParentX.genes = new int[Num_Feature];
                ParentY.genes = new int[Num_Feature];
                for (int ii = 0; ii < Num_Feature; ii++)
                {
                    ParentX.genes[ii] = Parent[ParentX_Index].genes[ii];
                    ParentY.genes[ii] = Parent[ParentY_Index].genes[ii];
                }

                if (Check_random(probability))
                {
                    int Random_Point = Rand.Next(1, Num_Feature);

                    Chromosome child1 = new Chromosome();
                    Chromosome child2 = new Chromosome();

                    child1.genes = new int[Num_Feature];
                    child2.genes = new int[Num_Feature];

                    for (int j = 0; j < Random_Point; j++)
                    {
                        child1.genes[j] = ParentX.genes[j];
                        child2.genes[j] = ParentY.genes[j];
                    }

                    for (int j = Random_Point; j < Num_Feature; j++)
                    {
                        child1.genes[j] = ParentY.genes[j];
                        child2.genes[j] = ParentX.genes[j];
                    }

                    offspring.Add(child1);
                    offspring.Add(child2);
                }

                else
                {
                    offspring.Add(ParentX);
                    offspring.Add(ParentY);
                }
            }
            Parent.Clear();
            for (int i = 0; i < offspring.Count; i++)
                Parent.Add(offspring[i]);
        }

        public void Mutate(double probability)
        {

            for (int i = 1; i < Parent.Count; i++)
            {
                for (int mutatePosition = 0; mutatePosition < Num_Feature; mutatePosition++)
                {
                    if (Check_random(probability))
                    {
                        if (Parent[i].genes[mutatePosition] == 0)
                            Parent[i].genes[mutatePosition] = 1;
                        else
                            Parent[i].genes[mutatePosition] = 0;
                    }
                }

            }

        }

        private void CalcFitness()
        {
            totalFitness = 0;
            double Max_Fit = double.MinValue;
            for (int k = 0; k < Parent.Count; k++)
            {
                List<Data> T_Data = new List<Data>();
                List<Data> V_Data = new List<Data>();

                T_Data.Clear();
                V_Data.Clear();

                for (int i = 0; i < Train_Data.Count; i++)
                {
                    Data data = new Data();
                    data.Att = new double[Omega * Num_Com];
                    data.Class = Train_Data[i].Class;
                    int index = 0;
                    for (int j = 0; j < Num_Feature; j++)
                    {
                        if (Parent[k].genes[j] == 1)
                        {
                            data.Att[index] = Train_Data[i].Att[j];
                            index++;
                        }
                    }
                    T_Data.Add(data);
                }

                for (int i = 0; i < Valid_Data.Count; i++)
                {
                    Data data = new Data();
                    data.Att = new double[Omega * Num_Com];
                    data.Class = Valid_Data[i].Class;
                    int index = 0;
                    for (int j = 0; j < Num_Feature; j++)
                    {
                        if (Parent[k].genes[j] == 1)
                        {
                            data.Att[index] = Valid_Data[i].Att[j];
                            index++;
                        }
                    }
                    V_Data.Add(data);
                }
                KNN knn = new KNN(T_Data, V_Data, 3, Num_Class);
                Parent[k].Accuracy = knn.Run_KNN();

                //NN nn = new NN(T_Data, V_Data, 40, 10, 0.1);
                //Parent[k].Accuracy = nn.Run_NN();

                double sum=0;
                for (int i = 0; i < Num_Feature; i++)
                {
                    for (int j = i; j < Num_Feature; j++)
                    {
                        if ((Parent[k].genes[i] == 1) && (Parent[k].genes[j] == 1))
                            sum += Sim[i, j];
                    }
                }
                Parent[k].Sum_Sim = sum;

                double Number = ((Omega * Num_Com) * (Omega * Num_Com - 1)) / 2.0;

                Parent[k].Fitness = Parent[k].Accuracy / (Parent[k].Sum_Sim / Number);
                totalFitness += Parent[k].Fitness;

                if (Parent[k].Fitness > Max_Fit)
                {
                    Best_Index = k;
                    Max_Fit = Parent[k].Fitness;
                }
            }
        }

        private void CalcFitness2()
        {
            totalFitness = 0;
            double Max_Fit = double.MinValue;
            List<int> S = new List<int>();
            double[] Pre_Fit = new double[Parent.Count];
            for (int i = 0; i < Parent.Count; i++)
            {
                S.Clear();
                for (int j = 0; j < Num_Feature; j++)
                {
                    if (Parent[i].genes[j] == 1)
                        S.Add(j);
                }
                Pre_Fit[i] = criteration.Calc_Criterion_Supervised2(S);
            }

            Ctrit_Normalization(ref Pre_Fit);
            for (int i = 0; i < Parent.Count; i++)
            {
                Parent[i].Fitness = Pre_Fit[i];
                totalFitness += Parent[i].Fitness;
                if (Parent[i].Fitness > Max_Fit)
                {
                    Best_Index = i;
                    Max_Fit = Parent[i].Fitness;
                }
            }


        }

        private void Calc_Clusters()
        {
            for (int i = 0; i < Parent.Count; i++)
            {
                Parent[i].Cluster = new List<int>[Num_Com];
                for (int j = 0; j < Num_Com; j++)
                {
                    Parent[i].Cluster[j] = new List<int>();
                    Parent[i].Cluster[j].Clear();
                }

                for (int j = 0; j < Num_Feature; j++)
                    if (Parent[i].genes[j] == 1)
                        Parent[i].Cluster[Com[j]].Add(j);
            }
        }

        private void Repar_Operation_Random()
        {
            int Chrom_Count = Parent.Count;
            int R;
            int Index;
            List<int> Temp_List = new List<int>();
            for (int i = 0; i < Chrom_Count; i++)
            {
                for (int j = 0; j < Num_Com; j++)
                {
                    if (Parent[i].Cluster[j].Count > Omega)
                    {
                        Temp_List.Clear();
                        for (int l = 0; l < Parent[i].Cluster[j].Count; l++)
                        {
                            Temp_List.Add(Parent[i].Cluster[j][l]);
                            Parent[i].genes[Parent[i].Cluster[j][l]] = 0;
                        }

                        Parent[i].Cluster[j].Clear();
                        for (int k = 0; k < Omega; k++)
                        {
                            R = random.Next(Temp_List.Count);
                            Index = Temp_List[R];
                            Parent[i].genes[Index] = 1;
                            Parent[i].Cluster[j].Add(Index);
                            Temp_List.Remove(Index);
                        }
                    }
                    else if (Parent[i].Cluster[j].Count < Omega)
                    {
                        Temp_List.Clear();
                        for (int l = 0; l < Com_List[j].Count; l++)
                            Temp_List.Add(Com_List[j][l]);

                        for (int l = 0; l < Parent[i].Cluster[j].Count; l++)
                            Temp_List.Remove(Parent[i].Cluster[j][l]);

                        for (int k = Parent[i].Cluster[j].Count; k < Omega; k++)
                        {
                            R = random.Next(Temp_List.Count);
                            Index = Temp_List[R];
                            Parent[i].genes[Index] = 1;
                            Parent[i].Cluster[j].Add(Index);
                            Temp_List.Remove(Index);
                        }
                    }
                }
            }
        }

        private void Repar_Operation_Score()
        {
            int Chrom_Count = Parent.Count;
            int Index=0;
            List<int> Temp_List = new List<int>();
            for (int i = 0; i < Chrom_Count; i++)
            {
                for (int j = 0; j < Num_Com; j++)
                {
                    if (Parent[i].Cluster[j].Count > Omega)
                    {
                        Temp_List.Clear();
                        int Count = Parent[i].Cluster[j].Count;
                        List<double> Score=new List<double>();

                        for (int l = 0; l < Count; l++)
                        {
                            Temp_List.Add(Parent[i].Cluster[j][l]);
                            Score.Add(Power[Parent[i].Cluster[j][l]]);
                        }

                        for (int k = 0; k <Count-Omega ; k++)
                        {
                            double min = Score.Min();
                            int Min_Index = Score.IndexOf(min);
                            Index = Temp_List[Min_Index];
                            Parent[i].genes[Index] = 0;
                            Parent[i].Cluster[j].Remove(Index);
                            Score.Remove(min);
                            Temp_List.Remove(Index);
                        }
                    }

                    else if (Parent[i].Cluster[j].Count < Omega)
                    {
                        Temp_List.Clear();
                        int Count = Parent[i].Cluster[j].Count;
                        List<double> Score = new List<double>();

                        for (int l = 0; l < Com_List[j].Count; l++)
                            Temp_List.Add(Com_List[j][l]);

                        for (int l = 0; l < Count; l++)
                            Temp_List.Remove(Parent[i].Cluster[j][l]);

                        for (int l = 0; l < Temp_List.Count; l++)
                            Score.Add(Power[Temp_List[l]]);

                        for (int k = Count; k < Omega; k++)
                        {
                            double max = Score.Max();
                            int max_index = Score.IndexOf(max);
                            Index = Temp_List[max_index];
                            Parent[i].genes[Index] = 1;
                            Parent[i].Cluster[j].Add(Index);
                            Temp_List.Remove(Index);
                            Score.Remove(max);
                        }
                    }
                }
            }
        }

        class FitnessComparator : Comparer<Chromosome>
        {
            public override int Compare(Chromosome x, Chromosome y)
            {
                if (x.Fitness == y.Fitness)
                    return 0;
                else if (x.Fitness < y.Fitness)
                    return 1;
                else
                    return -1;
            }
        }

        private bool Check_random(double probability)
        {
            if (random.NextDouble() < probability)
                return true;
            else
                return false;
        }

        void Set_Com_List()
        {
            for (int i = 0; i < Num_Com; i++)
            {
                Com_List[i] = new List<int>();
                Com_List[i].Clear();
            }

            for (int i = 0; i < Num_Feature; i++)
                Com_List[Com[i]].Add(i);
        }

        void Set_Train_Valid()
        {
            Train_Data = new List<Data>();
            Valid_Data = new List<Data>();

            Train_Data.Clear();
            Valid_Data.Clear();
            int Count = All_Data.Count;
            for (int i = 0; i < Convert.ToInt32(0.5 * Count); i++)
                Train_Data.Add(All_Data[i]);

            for (int i = Convert.ToInt32(0.5 * Count); i < Count; i++)
                Valid_Data.Add(All_Data[i]);
        }

        List<int> Final_Select(Chromosome Final_Chromosome)
        {
            List<int> R = new List<int>();
            for (int i = 0; i < Num_Feature; i++)
                if (Final_Chromosome.genes[i] == 1)
                    R.Add(i);

            return R;
        }

        private void Ctrit_Normalization(ref double[] Power)
        {
            int Num_Ant = Power.Length;

            double Max = double.MinValue;
            double Min = double.MaxValue;

            for (int i = 0; i < Num_Ant; i++)
            {
                if (Power[i] > Max)
                    Max = Power[i];

                if (Power[i] < Min)
                    Min = Power[i];
            }

            for (int i = 0; i < Num_Ant; i++)
            {
                Power[i] = (Power[i] - Min) / (Max - Min);
            }

        }

        private Chromosome Best(List<Chromosome> Ch_List)
        {
            int Best_Fit_index = 0;
            double Best_Fit = 0;
            for (int i = 0; i < Ch_List.Count; i++)
            {
                if (Ch_List[i].Fitness > Best_Fit)
                {
                    Best_Fit = Ch_List[i].Fitness;
                    Best_Fit_index = i;
                }
            }

            int Wrost_Fit_index = 0;
            double Wrost_Fit = double.MaxValue;
            for (int i = 0; i < Ch_List.Count; i++)
            {
                if (Ch_List[i].Fitness < Best_Fit)
                {
                    Wrost_Fit = Ch_List[i].Fitness;
                    Wrost_Fit_index = i;
                }
            }

            return Ch_List[Best_Fit_index];

        }

    }
}
