﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FeatureSelection
{
    class NN
    {
        int iteration;
        int hidden_neurons;
        double alpha;
        int Input_Neurons;
        int Output_Neurons;
        double[,] V;
        double[,] W;
        double[,] DeltaV;
        double[,] DeltaW;
        double[] Zj;
        double[] DeltaK;
        double[] DeltaJ;

        List<string> Input_Class;
        List<string> Output_Class;


        Random random = new Random();

        List<Data> Train_Data;
        List<Data> Test_Data;
        bool Print;

        public NN(List<Data> train, List<Data> valid, int it, int hid, double alfa)
        {
            Train_Data = train;
            Test_Data = valid;

            iteration = it;
            hidden_neurons = hid;
            alpha = alfa;
            Output_Neurons = 2;
            Input_Neurons = train[0].Att.Length;

        }

        public double Run_NN()
        {
            Train();
            return Test();
        }

        public void Train()
        {

            V = new double[Input_Neurons + 1, hidden_neurons];
            W = new double[hidden_neurons + 1, Output_Neurons];
            DeltaV = new double[Input_Neurons + 1, hidden_neurons];
            DeltaW = new double[hidden_neurons + 1, Output_Neurons];
            Zj = new double[hidden_neurons];
            DeltaK = new double[Output_Neurons];
            DeltaJ = new double[hidden_neurons];

            Random_Weight();

            for (int iter = 0; iter < iteration; iter++)
            {
                for (int i = 0; i < Train_Data.Count; i++)
                {
                    for (int j = 0; j < hidden_neurons; j++)
                    {
                        double z_in = V[0, j];
                        for (int k = 1; k < Input_Neurons + 1; k++)
                        {
                            z_in += (V[k, j] * Train_Data[i].Att[k - 1]);
                        }
                        Zj[j] = Activation_Function(z_in);
                    }
                    for (int k = 0; k < Output_Neurons; k++)
                    {
                        double y_in = W[0, k];
                        for (int j = 1; j < hidden_neurons + 1; j++)
                        {
                            y_in += (W[j, k] * Zj[j - 1]);
                        }
                        double y_k = Activation_Function(y_in);
                        DeltaK[k] = (Train_Data[i].Class - y_k) * f_prim(y_k);
                        DeltaW[0, k] = alpha * DeltaK[k];
                    }
                    for (int j = 1; j < hidden_neurons + 1; j++)
                    {
                        for (int k = 0; k < Output_Neurons; k++)
                        {
                            DeltaW[j, k] = alpha * DeltaK[k] * Zj[j - 1];
                        }
                    }
                    for (int j = 1; j < hidden_neurons + 1; j++)
                    {
                        double delta_in = 0;
                        for (int k = 0; k < Output_Neurons; k++)
                        {
                            delta_in += DeltaK[k] * W[j, k];
                        }
                        DeltaJ[j - 1] = delta_in * f_prim(Zj[j - 1]);
                        DeltaV[0, j - 1] = alpha * DeltaJ[j - 1];
                    }
                    for (int j = 1; j < Input_Neurons + 1; j++)
                    {
                        for (int k = 0; k < hidden_neurons; k++)
                        {
                            DeltaV[j, k] = alpha * DeltaJ[k] * Train_Data[i].Att[j - 1];
                        }
                    }
                    for (int j = 0; j < hidden_neurons + 1; j++)
                    {
                        for (int k = 0; k < Output_Neurons; k++)
                        {
                            W[j, k] += DeltaW[j, k];
                        }
                    }
                    for (int j = 0; j < Input_Neurons + 1; j++)
                    {
                        for (int k = 0; k < hidden_neurons; k++)
                        {
                            V[j, k] += DeltaV[j, k];
                        }
                    }
                }
                //alpha *= 0.9; //End of Train Dataes
            }
        }

        public double Test()
        {
            Input_Class = new List<string>();
            Output_Class = new List<string>();
            double Accuracy;
            int Num_Success = 0;
            for (int i = 0; i < Test_Data.Count; i++)
            {
                double[] z_j = new double[hidden_neurons];
                int[] y_k = new int[Output_Neurons];
                for (int j = 0; j < hidden_neurons; j++)
                {
                    double z_inj = V[0, j];
                    for (int k = 0; k < Input_Neurons; k++)
                    {
                        z_inj += Test_Data[i].Att[k] * V[k + 1, j];
                    }
                    z_j[j] = Activation_Function(z_inj);
                }
                for (int j = 0; j < Output_Neurons; j++)
                {
                    double y_ink = W[0, j];
                    for (int k = 0; k < hidden_neurons; k++)
                    {
                        y_ink += z_j[k] * W[k + 1, j];
                    }
                    if (Activation_Function(y_ink) >= 0)
                        y_k[j] = 1;
                    else
                        y_k[j] = -1;
                }
                string Accu = "False";
                if (y_k[0] == Test_Data[i].Class)
                {
                    Num_Success++;
                    Accu = "True";
                }
            }
            Accuracy = (Convert.ToDouble(Num_Success) / Test_Data.Count);
            return Accuracy;
        }

        public void Random_Weight()
        {
            for (int i = 0; i < Input_Neurons + 1; i++)
            {
                for (int j = 0; j < hidden_neurons; j++)
                {
                    V[i, j] = Between_Random(-0.5, 0.5);
                }
            }
            for (int i = 0; i < hidden_neurons + 1; i++)
            {
                for (int j = 0; j < Output_Neurons; j++)
                {
                    W[i, j] = Between_Random(-0.5, 0.5);
                }
            }
        }

        public double Between_Random(double low_value, double high_value)
        {
            return random.NextDouble() * (high_value - low_value) + low_value;
        }

        public double Activation_Function(double x)
        {
            double y = 2.0 / (1 + Math.Exp(-x)) - 1;
            return y;
        }

        public double f_prim(double x)
        {
            double y = 0.5 * (1 + x) * (1 - x);
            return y;
        }
    }
}
