﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FeatureSelection
{
    class Chromosome
    {
        public int[] genes;
        public double Fitness;
        public double Sum_Sim;
        public double Accuracy;
        public double cumulative_fitness;
        public List<int>[] Cluster;

        public Chromosome()
        {
        } 
    }
}
