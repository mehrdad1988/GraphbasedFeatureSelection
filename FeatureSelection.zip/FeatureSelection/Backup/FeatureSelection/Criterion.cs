﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FeatureSelection
{
    class Criterion
    {
        List<Data> Train_Data;
        List<int> Classes;
        double[,] A;
        int m, n;
        List<Data> New_Train_Data;
        double[,] Sigma_w;
        double[,] Sigma_b;


        public Criterion(List<Data> train_data)
        {
            Train_Data = train_data;
            m = Train_Data.Count;
            n = Train_Data[0].Att.Length;
            A = new double[m, n];
            for (int i = 0; i < m; i++)
                for (int j = 0; j < n; j++)
                    A[i, j] = Train_Data[i].Att[j];
        }

        public double Calc_Criterion_Supervised(List<int> S)
        {
            int Number_Classes = Calc_Number_Classes();
            Creat_New_Data(S);
            int Num_Feature = New_Train_Data[0].Att.Length;
            List<Data>[] Data_Class = new List<Data>[Number_Classes];
            double[,] Mio = new double[Number_Classes, Num_Feature];
            double[] Mio_Bar = new double[Num_Feature];
            double[,] Sigma = new double[Number_Classes, Num_Feature];
            double[] S_w = new double[Num_Feature];
            double[] S_b = new double[Num_Feature];
            double[] S_m = new double[Num_Feature];
            double Trace_S_w = 0;
            double Trace_S_m = 0;
            double[] P = new double[Number_Classes];

            for (int i = 0; i < Number_Classes; i++)
                Data_Class[i] = new List<Data>();

            for (int i = 0; i < Train_Data.Count; i++)
                Data_Class[Classes.IndexOf((New_Train_Data[i].Class))].Add(New_Train_Data[i]);

            for (int i = 0; i < Number_Classes; i++)
            {
                P[i] = (double)Data_Class[i].Count / (double)New_Train_Data.Count;
            }

            for (int i = 0; i < Number_Classes; i++)
            {
                for (int j = 0; j < Num_Feature; j++)
                {
                    double Sum = 0;
                    for (int k = 0; k < Data_Class[i].Count; k++)
                    {
                        Sum += Data_Class[i][k].Att[j];
                    }
                    Mio[i, j] = Sum / Data_Class[i].Count;
                }
            }

            for (int i = 0; i < Number_Classes; i++)
            {
                for (int j = 0; j < Num_Feature; j++)
                {
                    double Sum = 0;
                    for (int k = 0; k < Data_Class[i].Count; k++)
                    {
                        Sum += Math.Pow(Data_Class[i][k].Att[j] - Mio[i, j], 2);
                    }
                    Sigma[i, j] = Sum / Data_Class[i].Count;
                }
            }

            for (int j = 0; j < Num_Feature; j++)
            {
                for (int i = 0; i < Number_Classes; i++)
                {
                    S_w[j] += P[i] * Sigma[i, j];
                }
            }

            for (int j = 0; j < Num_Feature; j++)
            {
                double Sum = 0;
                for (int i = 0; i < Number_Classes; i++)
                {
                    Sum += P[i] * Mio[i, j];
                }
                Mio_Bar[j] = Sum;
            }

            for (int i = 0; i < Number_Classes; i++)
            {
                for (int j = 0; j < Num_Feature; j++)
                {
                    S_b[j] += P[i] * Math.Pow(Mio[i, j] - Mio_Bar[j], 2);
                }
            }

            for (int j = 0; j < Num_Feature; j++)
            {
                S_m[j] = S_w[j] + S_b[j];
            }
            //
            double[] S_m_New = new double[Num_Feature];
            for (int j = 0; j < Num_Feature; j++)
            {
                double Sum = 0;
                for (int i = 0; i < New_Train_Data.Count; i++)
                {
                    Sum += Math.Pow(New_Train_Data[i].Att[j] - Mio_Bar[j], 2);
                }
                S_m_New[j] = Sum / New_Train_Data.Count;
            }
            double Trace_S_m_New = 0;

            //

            for (int j = 0; j < Num_Feature; j++)
            {
                Trace_S_w += S_w[j];
                Trace_S_m += S_m[j];
                Trace_S_m_New += S_m_New[j];
            }
            if (double.IsNaN(Trace_S_m / Trace_S_w))
                Trace_S_m_New = 0;

            return Trace_S_m / Trace_S_w;
        }

        public double Calc_Criterion_Supervised2(List<int> S)
        {
            S.Sort();
            int Count = S.Count;
            double[,] WT_SigmaW_W = new double[Count, Count];
            double[,] WT_SigmaB_W = new double[Count, Count];

            double Trace_SigmaW = 0;
            double Trace_SigmaB = 0;

            for (int i = 0; i < Count; i++)
            {
                for (int j = i; j < Count; j++)
                {
                    WT_SigmaW_W[i, j] = Sigma_w[S[i], S[j]];
                    WT_SigmaW_W[j, i] = WT_SigmaW_W[i, j];

                    WT_SigmaB_W[i, j] = Sigma_b[S[i], S[j]];
                    WT_SigmaB_W[j, i] = WT_SigmaB_W[i, j];
                }
            }

            for (int i = 0; i < Count; i++)
            {
                Trace_SigmaW += WT_SigmaW_W[i, i];
                Trace_SigmaB += WT_SigmaB_W[i, i];
            }

            return Trace_SigmaB / Trace_SigmaW;
        }

        public void Pre_Calculation()
        {
            int Number_Classes = Calc_Number_Classes();
            int Num_Feature = Train_Data[0].Att.Length;
            List<Data>[] Data_Class = new List<Data>[Number_Classes];
            double[,] Mio = new double[Number_Classes, Num_Feature];
            double[] Mio_Bar = new double[Num_Feature];
            double[, ,] Sigma = new double[Number_Classes, Num_Feature, Num_Feature];
            double[] P = new double[Number_Classes];
            Sigma_w = new double[Num_Feature, Num_Feature];
            Sigma_b = new double[Num_Feature, Num_Feature];



            for (int i = 0; i < Number_Classes; i++)
                Data_Class[i] = new List<Data>();

            for (int i = 0; i < Train_Data.Count; i++)
                Data_Class[Classes.IndexOf((Train_Data[i].Class))].Add(Train_Data[i]);

            for (int i = 0; i < Number_Classes; i++)
                P[i] = (double)Data_Class[i].Count / (double)Train_Data.Count;



            for (int i = 0; i < Number_Classes; i++)
            {
                for (int j = 0; j < Num_Feature; j++)
                {
                    double Sum = 0;
                    for (int k = 0; k < Data_Class[i].Count; k++)
                    {
                        Sum += Data_Class[i][k].Att[j];
                    }
                    Mio[i, j] = Sum / Data_Class[i].Count;
                }
            }

            for (int j = 0; j < Num_Feature; j++)
            {
                double Sum = 0;
                for (int i = 0; i < Number_Classes; i++)
                {
                    Sum += P[i] * Mio[i, j];
                }
                Mio_Bar[j] = Sum;
            }

            for (int k = 0; k < Number_Classes; k++)
            {
                for (int i = 0; i < Num_Feature; i++)
                {
                    for (int j = i; j < Num_Feature; j++)
                    {
                        double Sum = 0;
                        int Count = Data_Class[k].Count;
                        for (int l = 0; l < Count; l++)
                        {
                            Sum += (Data_Class[k][l].Att[i] - Mio[k, i]) * (Data_Class[k][l].Att[j] - Mio[k, j]);
                        }
                        Sigma[k, i, j] = Sum / Count;
                        Sigma[k, j, i] = Sigma[k, i, j];
                    }
                }
            }

            for (int i = 0; i < Num_Feature; i++)
            {
                for (int j = i; j < Num_Feature; j++)
                {
                    double Sum = 0;
                    for (int k = 0; k < Number_Classes; k++)
                    {
                        Sum += P[k] * Sigma[k, i, j];
                    }
                    Sigma_w[i, j] = Sum;
                    Sigma_w[j, i] = Sum; ;
                }
            }

            for (int i = 0; i < Num_Feature; i++)
            {
                for (int j = i; j < Num_Feature; j++)
                {
                    double Sum = 0;
                    for (int k = 0; k < Number_Classes; k++)
                    {
                        Sum += P[k] * (Mio[k, i] - Mio_Bar[i]) * (Mio[k, j] - Mio_Bar[j]);
                    }
                    Sigma_b[i, j] = Sum;
                    Sigma_b[j, i] = Sum;
                }
            }
        }

        int Calc_Number_Classes()
        {
            Classes = new List<int>();
            int Count = Train_Data.Count;
            for (int i = 0; i < Count; i++)
            {
                if (!Classes.Contains(Train_Data[i].Class))
                    Classes.Add(Train_Data[i].Class);
            }
            return Classes.Count;
        }

        void Creat_New_Data(List<int> s)
        {
            New_Train_Data = new List<Data>();
            New_Train_Data.Clear();
            int Num_Attributes = Train_Data[0].Att.Length;
            for (int i = 0; i < Train_Data.Count; i++)
            {
                Data Temp = new Data();
                Temp.Att = new double[s.Count];
                Temp.Class = Train_Data[i].Class;
                int index = 0;
                for (int j = 0; j < Num_Attributes; j++)
                {
                    if (s.Contains(j))
                    {
                        Temp.Att[index] = Train_Data[i].Att[j];
                        index++;
                    }
                }
                New_Train_Data.Add(Temp);
            }
        }
    }
}
