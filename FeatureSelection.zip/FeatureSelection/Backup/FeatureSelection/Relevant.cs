﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FeatureSelection
{
    class Relevant
    {
        List<Data> Dataset;
        List<int> Classes;
        double[] Power;
        int[] Class_Index;
        int N;
        int Num_Attr;
        double Lambda;

        public Relevant(List<Data> dataset)
        {
            Dataset = dataset;
            N = Dataset.Count;
            Num_Attr = Dataset[0].Att.Length;
            Power = new double[Num_Attr];
            Lambda = 0.1;
        }

        public double[] Run_Constraint_Score(int Num_Class)
        {
            int Number_Classes = Num_Class;
            List<Data>[] Data_Class = new List<Data>[Number_Classes];
            for (int i = 0; i < Number_Classes; i++)
                Data_Class[i] = new List<Data>();

            for (int i = 0; i < N; i++)
                Data_Class[Dataset[i].Class].Add(Dataset[i]);

            double[] M = new double[Num_Attr];
            double[] C = new double[Num_Attr];
            for (int r = 0; r < Num_Attr; r++)
            {
                for (int l = 0; l < Number_Classes; l++)
                {
                    int Count = Data_Class[l].Count;
                    for (int i = 0; i < Count; i++)
                    {
                        for (int j = i + 1; j < Count; j++)
                        {
                            M[r] += Math.Pow(Data_Class[l][i].Att[r] - Data_Class[l][j].Att[r], 2);
                        }
                    }
                }
            }

            for (int r = 0; r < Num_Attr; r++)
            {
                for (int i = 0; i < Number_Classes; i++)
                {
                    for (int j = i + 1; j < Number_Classes; j++)
                    {
                        for (int ii = 0; ii < Data_Class[i].Count; ii++)
                        {
                            for (int jj = 0; jj < Data_Class[j].Count; jj++)
                            {
                                C[r] += Math.Pow(Data_Class[i][ii].Att[r] - Data_Class[j][jj].Att[r], 2);
                            }
                        }
                    }
                }
            }

            //for (int r = 0; r < Num_Attr; r++)
            //    Power[r] = C[r] / M[r];

            for (int r = 0; r < Num_Attr; r++)
                Power[r] = Lambda * C[r] - M[r];

            return Power;
        }

        public double[] Run_Fisher_Score(int Num_Class)
        {
            int Number_Classes = Calc_Number_Classes();
            List<Data>[] Data_Class = new List<Data>[Number_Classes];
            for (int i = 0; i < Number_Classes; i++)
                Data_Class[i] = new List<Data>();

            for (int i = 0; i < N; i++)
                Data_Class[Classes.IndexOf((Dataset[i].Class))].Add(Dataset[i]);

            double[] A_Bar = new double[Num_Attr];

            for (int r = 0; r < Num_Attr; r++)
            {
                double Sigma = 0;
                for (int i = 0; i < Dataset.Count; i++)
                {
                    Sigma += Dataset[i].Att[r];
                }
                A_Bar[r] = Sigma / Dataset.Count;
            }

            double[,] A_Bar_v = new double[Number_Classes, Num_Attr];
            for (int r = 0; r < Num_Attr; r++)
            {
                for (int i = 0; i < Number_Classes; i++)
                {
                    double Sigma = 0;
                    for (int k = 0; k < Data_Class[i].Count; k++)
                    {
                        Sigma += Data_Class[i][k].Att[r];
                    }
                    A_Bar_v[i, r] = Sigma / Data_Class[i].Count;
                }
            }

            double[,] Var_v = new double[Number_Classes, Num_Attr];
            for (int r = 0; r < Num_Attr; r++)
            {
                for (int i = 0; i < Number_Classes; i++)
                {
                    double Sigma = 0;
                    for (int k = 0; k < Data_Class[i].Count; k++)
                    {
                        Sigma += Math.Pow(Data_Class[i][k].Att[r] - A_Bar_v[i, r], 2);
                    }
                    Var_v[i, r] = Sigma / (Data_Class[i].Count);
                }
            }

            for (int r = 0; r < Num_Attr; r++)
            {
                double Sigma1 = 0;
                double Sigma2 = 0;
                for (int i = 0; i < Number_Classes; i++)
                {
                    Sigma1 += (Data_Class[i].Count * Math.Pow(A_Bar_v[i, r] - A_Bar[r], 2));
                    Sigma2 += (Data_Class[i].Count * Var_v[i, r]);
                }
                Power[r] = Sigma1 / Sigma2;
            }

            return Power;
        }

        public double[] Run_Laplacian_Scor()
        {
            int m = Dataset.Count;
            int K = 20;
            double[,] Dist = new double[m, m];
            double[,] S = new double[m, m];
            double[] D = new double[m];
            for (int i = 0; i < m; i++)
            {
                for (int j = i + 1; j < m; j++)
                {
                    double Sum = 0;
                    for (int k = 0; k < Num_Attr; k++)
                    {
                        if (!double.IsNaN(Dataset[i].Att[k] - Dataset[j].Att[k]))
                            Sum += Math.Pow(Dataset[i].Att[k] - Dataset[j].Att[k], 2);
                    }
                    Dist[i, j] = Math.Sqrt(Sum);
                    Dist[j, i] = Dist[i, j];
                }
            }

            for (int i = 0; i < m; i++)
                Dist[i, i] = double.MaxValue;

            List<int> Index = new List<int>();
            List<double> Distance = new List<double>();
            List<int>[] Nearest = new List<int>[m];
            double[] A_Bar = new double[Num_Attr];
            for (int i = 0; i < m; i++)
            {
                Index.Clear();
                Distance.Clear();
                Nearest[i] = new List<int>();
                for (int x = 0; x < m; x++)
                    Index.Add(x);

                for (int x = 0; x < m; x++)
                    Distance.Add(Dist[i, x]);

                for (int k = 0; k < K; k++)
                {
                    double Min = Distance.Min();
                    int Min_Index = Distance.IndexOf(Min);
                    Nearest[i].Add(Index[Min_Index]);
                    Index.RemoveAt(Min_Index);
                    Distance.RemoveAt(Min_Index);
                }
                for (int x = 0; x < m; x++)
                {
                    if (Nearest[i].Contains(x))
                        S[i, x] = Math.Exp(-Dist[i, x] / 5);
                }
            }

            for (int i = 0; i < m; i++)
            {
                for (int j = 0; j < m; j++)
                    if (j != i)
                        D[i] += S[i, j];
            }

            for (int r = 0; r < Num_Attr; r++)
            {
                double Sum = 0;
                for (int j = 0; j < m; j++)
                {
                    Sum += Dataset[j].Att[r];
                }
                A_Bar[r] = Sum / m;
            }

            for (int r = 0; r < Num_Attr; r++)
            {
                double Sigma1 = 0;
                double Sigma2 = 0;
                for (int i = 0; i < m; i++)
                {
                    for (int j = i + 1; j < m; j++)
                    {
                        Sigma1 += (Math.Pow(Dataset[i].Att[r] - Dataset[j].Att[r], 2) * S[i, j]);
                    }
                    Sigma2 += (Math.Pow(Dataset[i].Att[r] - A_Bar[r], 2) * D[i]);
                }
                //Power[r] = Sigma1 / Sigma2;
                Power[r] = Sigma2 / Sigma1;
            }

            return Power;
        }

        public double[] Run_Term_Variance()
        {
            double[] A_Bar = new double[Num_Attr];

            for (int r = 0; r < Num_Attr; r++)
            {
                double Sigma = 0;
                for (int i = 0; i < Dataset.Count; i++)
                {
                    Sigma += Dataset[i].Att[r];
                }
                A_Bar[r] = Sigma / Dataset.Count;
            }

            for (int r = 0; r < Num_Attr; r++)
            {
                double Sigma = 0;
                for (int i = 0; i < Dataset.Count; i++)
                {
                    Sigma += Math.Pow(Dataset[i].Att[r] - A_Bar[r], 2);
                }
                Power[r] = Sigma / (Dataset.Count - 1);
            }
            return Power;
        }

        int Calc_Number_Classes()
        {
            Classes = new List<int>();
            int Count = Dataset.Count;
            for (int i = 0; i < Count; i++)
            {
                if (!Classes.Contains(Dataset[i].Class))
                    Classes.Add(Dataset[i].Class);
            }
            //for (int i = 0; i < Classes.Count; i++)
            //{
            //    Class_Index[Classes[i]] = i;
            //}
            return Classes.Count;
        }

        public List<int> Select_Feature(int m)
        {
            List<int> Index = new List<int>();
            List<double> Score = new List<double>();
            List<int> Selected = new List<int>();

            for (int i = 0; i < Num_Attr; i++)
                Index.Add(i);

            for (int i = 0; i < Num_Attr; i++)
                Score.Add(Power[i]);

            for (int i = 0; i < m; i++)
            {
                double Best = Score.Max();
                int Best_Index = Score.IndexOf(Best);
                Selected.Add(Index[Best_Index]);
                Score.RemoveAt(Best_Index);
                Index.RemoveAt(Best_Index);
            }
            return Selected;
        }
    }
}
