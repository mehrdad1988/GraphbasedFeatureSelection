﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FeatureSelection
{
    class Data
    {
        public double[] Att;
        public int Class;

        public Data()
        {

        }
    }
}
