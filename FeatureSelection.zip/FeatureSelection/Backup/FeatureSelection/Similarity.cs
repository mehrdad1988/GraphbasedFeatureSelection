﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FeatureSelection
{
    class Similarity
    {
        int Type;
        double[,] Sim;
        List<Data> DataSet;
        int Count;
        int Num_Attr;

        public Similarity(List<Data> dataset, int type)
        {
            DataSet = dataset;
            Type = type;
            Num_Attr = DataSet[0].Att.Length;
            Sim = new double[Num_Attr, Num_Attr];
            Count = DataSet.Count;
        }

        public double[,] Calc_Sim()
        {
            if (Type == 0) // Correlation
            {
                Calc_Cor();
            }

            if (Type == 1) // Cosine
            {
                Calc_Cos();
            }

            if (Type == 2) // Jacard
            {
                Calc_Jaccard();
            }

            if (Type == 3) // Pearson
            {
                Calc_Pearson();
            }

            if (Type == 4)
            {
                Calc_Maximal_Information_Compression();
            }

            return Sim;
        }

        private void Calc_Cor()
        {
            double[] Mean = new double[Num_Attr];
            for (int i = 0; i < Num_Attr; i++)
            {
                double Sum = 0;
                for (int k = 0; k < Count; k++)
                {
                    Sum += DataSet[k].Att[i];
                }
                Mean[i] = Sum / (double)Count;
            }

            for (int i = 0; i < Num_Attr; i++)
            {
                for (int j = i + 1; j < Num_Attr; j++)
                {
                    double Sum1 = 0;
                    double Sum2 = 0;
                    double Sum3 = 0;
                    for (int k = 0; k < Count; k++)
                    {
                        Sum1 += ((DataSet[k].Att[i] - Mean[i]) * (DataSet[k].Att[j] - Mean[j]));
                        Sum2 += Math.Pow(DataSet[k].Att[i] - Mean[i], 2);
                        Sum3 += Math.Pow(DataSet[k].Att[j] - Mean[j], 2);
                    }
                    Sim[i, j] = Math.Abs(Sum1 / (Math.Sqrt(Sum2) * Math.Sqrt(Sum3)));
                    Sim[j, i] = Sim[i, j];
                }
            }
        }

        private void Calc_Cos()
        {
            for (int i = 0; i < Num_Attr; i++)
            {
                for (int j = i + 1; j < Num_Attr; j++)
                {
                    double Sum1 = 0;
                    double Sum2 = 0;
                    double Sum3 = 0;
                    for (int k = 0; k < Count; k++)
                    {
                        Sum1 += DataSet[k].Att[i] * DataSet[k].Att[j];
                        Sum2 += Math.Pow(DataSet[k].Att[i], 2);
                        Sum3 += Math.Pow(DataSet[k].Att[j], 2);
                    }
                    Sim[i, j] = Math.Abs(Sum1 / ((Math.Sqrt(Sum2) * Math.Sqrt(Sum3))));
                    Sim[j, i] = Sim[i, j];
                }
            }
        }

        private void Calc_Jaccard()
        {
            for (int i = 0; i < Num_Attr; i++)
            {
                for (int j = i; j < Num_Attr; j++)
                {
                    double Sum1 = 0;
                    double Sum2 = 0;
                    double Sum3 = 0;
                    for (int k = 0; k < Count; k++)
                    {
                        Sum1 += DataSet[k].Att[i] * DataSet[k].Att[j];
                        Sum2 += Math.Pow(DataSet[k].Att[i], 2);
                        Sum3 += Math.Pow(DataSet[k].Att[j], 2);
                    }
                    Sim[i, j] = Math.Abs(Sum1 / (Sum2 + Sum3 - Sum1));
                    Sim[j, i] = Sim[i, j];
                }
            }
        }

        private void Calc_Pearson()
        {

        }

        private void Calc_Maximal_Information_Compression()
        {
            double[] mean = new double[Num_Attr];
            double[] var = new double[Num_Attr];
            double[,] cov = new double[Num_Attr, Num_Attr];
            double[,] p = new double[Num_Attr, Num_Attr];

            for (int j = 0; j < Num_Attr; j++)
            {
                double Sum = 0;
                for (int i = 0; i < Count; i++)
                {
                    Sum += DataSet[i].Att[j];
                }
                mean[j] = Sum / Count;
            }

            for (int j = 0; j < Num_Attr; j++)
            {
                double Sum = 0;
                for (int i = 0; i < Count; i++)
                {
                    Sum += Math.Pow(DataSet[i].Att[j] - mean[j], 2);
                }
                var[j] = Sum / (Count - 1);
            }

            for (int i = 0; i < Num_Attr; i++)
            {
                for (int j = i; j < Num_Attr; j++)
                {
                    double Sum = 0;
                    for (int k = 0; k < Count; k++)
                    {
                        Sum += (DataSet[k].Att[i] - mean[i]) * (DataSet[k].Att[j] - mean[j]);
                    }
                    cov[i, j] = Sum / (Count - 1);
                    cov[j, i] = cov[i, j];
                }
            }

            for (int i = 0; i < Num_Attr; i++)
            {
                for (int j = i; j < Num_Attr; j++)
                {
                    p[i, j] = cov[i, j] / Math.Sqrt(var[i] * var[j]);
                    p[j, i] = p[i, j];
                }
            }

            for (int i = 0; i < Num_Attr; i++)
            {
                for (int j = 0; j < Num_Attr; j++)
                {
                    Sim[i, j] = var[i] + var[j] - Math.Sqrt(Math.Pow(var[i] + var[j], 2) - 4 * var[i] * var[j] * (1 - Math.Pow(p[i, j], 2)));
                }
            }
        }
    }
}
