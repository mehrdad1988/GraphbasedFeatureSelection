﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FeatureSelection
{
    class Graph
    {
        double[,] W;
        double[] Power;
        List<int> Reminder;
        List<int> Removed;
        int[] Com;
        List<int>[] Com_List;
        int N;
        int K;
        int Num_Com;
        double Alfa;
        double Beta;
        double Threshold;

        public Graph(double[,] w, double[] power, int[] com, int num_com, int k, double threshold)
        {
            W = w;
            Power = power;
            Com = com;
            Num_Com = num_com;
            K = k;
            Com_List = new List<int>[Num_Com];
            N = Power.Length;
            Threshold = threshold;
            Removed = new List<int>();
            Reminder = new List<int>();
            for (int i = 0; i < N; i++)
                Reminder.Add(i);

            for (int i = 0; i < N; i++)
                W[i, i] = 0;

            Set_Com_List();
            Alfa = 1;
            Beta = 1;
        }

        public List<int> Run_Graph()
        {
            List<double>[] Centrality = new List<double>[Num_Com];
            double Befor;
            double After;
            bool Change = true;
            while (Change)
            {
                Change = false;
                for (int i = 0; i < Num_Com; i++)
                {
                    int n = Com_List[i].Count;
                    Centrality[i] = new List<double>();
                    Centrality[i].Clear();
                    Befor = Calc_Centrality_Befor(Com_List[i]);
                    for (int j = 0; j < n; j++)
                    {
                        After = Calc_Centrality_After(Com_List[i], j);
                        Centrality[i].Add(((Befor - After) / Befor));
                    }
                }

                Centrality_Normalization(ref Centrality);

                for (int i = 0; i < Num_Com; i++)
                {

                    int n = Com_List[i].Count;
                    double[] Power_Cent = new double[n];

                    for (int j = 0; j < n; j++)
                    {
                        Power_Cent[j] = Math.Pow(Power[Com_List[i][j]], Alfa) * Math.Pow(Centrality[i][j], Beta);
                    }

                    List<int> Removed = new List<int>();

                    for (int j = 0; j < n; j++)
                    {
                        if (Power_Cent[j] < Threshold)
                        {
                            Removed.Add(Com_List[i][j]);

                        }
                    }
                    if (Com_List[i].Count - Removed.Count >= K)
                    {
                        for (int l = 0; l < Removed.Count; l++)
                        {
                            Com_List[i].Remove(Removed[l]);
                            Change = true;
                        }
                    }
                }
            }
            return Final();
        }

        double Calc_Centrality_Befor(List<int> Community)
        {
            List<int> R = new List<int>();
            int n = Community.Count;
            double E_G = 0;
            double[] X1 = new double[n];
            for (int i = 0; i < n; i++)
                R.Add(Community[i]);

            for (int i = 0; i < n; i++)
            {
                double Sum = 0;
                for (int j = 0; j < n; j++)
                {
                    Sum += W[R[i], R[j]];
                }
                X1[i] = Sum;
            }


            double S1 = 0;
            double S2 = 0;
            for (int i = 0; i < n; i++)
            {
                S1 += Math.Pow(X1[i], 2);
            }

            for (int i = 0; i < n; i++)
            {
                for (int j = i + 1; j < n; j++)
                {
                    S2 += Math.Pow(W[R[i], R[j]], 2);
                }
            }
            E_G = S1 + (2 * S2);

            return E_G;
        }

        double Calc_Centrality_After(List<int> Community, int ii)
        {
            List<int> R = new List<int>();
            int n = Community.Count;
            double E_G_i = 0;
            double[] X1 = new double[n];
            double[] X2 = new double[n - 1];

            for (int i = 0; i < n; i++)
                R.Add(Community[i]);

            R.RemoveAt(ii);

            for (int i = 0; i < n - 1; i++)
            {
                double Sum = 0;
                for (int j = 0; j < n - 1; j++)
                {
                    Sum += W[R[i], R[j]];
                }
                X2[i] = Sum;
            }
            double S1 = 0;
            double S2 = 0;
            for (int i = 0; i < n - 1; i++)
            {
                S1 += Math.Pow(X2[i], 2);
            }

            for (int i = 0; i < n - 1; i++)
            {
                for (int j = i + 1; j < n - 1; j++)
                {
                    S2 += Math.Pow(W[R[i], R[j]], 2);
                }
            }
            E_G_i = S1 + (2 * S2);
            return E_G_i;
        }

        double Calc_Centrality(int ii, List<int> Community)
        {
            List<int> R = new List<int>();
            int n = Community.Count;
            double E_G = 0;
            double E_G_i = 0;
            double[] X1 = new double[n];
            double[] X2 = new double[n - 1];

            for (int i = 0; i < n; i++)
                R.Add(Community[i]);

            for (int i = 0; i < n; i++)
            {
                double Sum = 0;
                for (int j = 0; j < n; j++)
                {
                    Sum += W[R[i], R[j]];
                }
                X1[i] = Sum;
            }


            double S1 = 0;
            double S2 = 0;
            for (int i = 0; i < n; i++)
            {
                S1 += Math.Pow(X1[i], 2);
            }

            for (int i = 0; i < n; i++)
            {
                for (int j = i + 1; j < n; j++)
                {
                    S2 += Math.Pow(W[R[i], R[j]], 2);
                }
            }
            E_G = S1 + (2 * S2);

            //*************************************************
            R.RemoveAt(ii);
            for (int i = 0; i < n - 1; i++)
            {
                double Sum = 0;
                for (int j = 0; j < n - 1; j++)
                {
                    Sum += W[R[i], R[j]];
                }
                X2[i] = Sum;
            }
            S1 = 0;
            S2 = 0;
            for (int i = 0; i < n - 1; i++)
            {
                S1 += Math.Pow(X2[i], 2);
            }

            for (int i = 0; i < n - 1; i++)
            {
                for (int j = i + 1; j < n - 1; j++)
                {
                    S2 += Math.Pow(W[R[i], R[j]], 2);
                }
            }
            E_G_i = S1 + (2 * S2);

            //****************************************************

            return ((E_G - E_G_i) / (E_G));

        }

        void Set_Com_List()
        {
            for (int i = 0; i < Num_Com; i++)
            {
                Com_List[i] = new List<int>();
                for (int j = 0; j < N; j++)
                {
                    if (Com[j] == i)
                        Com_List[i].Add(j);
                }
            }
        }

        private void Centrality_Normalization(ref List<double>[] Cent)
        {
            int Num_C = Cent.Length;

            for (int c = 0; c < Num_C; c++)
            {
                double Sum = 0;
                int n = Cent[c].Count;

                for (int i = 0; i < n; i++)
                    Sum += Cent[c][i];
                double X_Bar = Sum / n;

                Sum = 0;
                for (int i = 0; i < n; i++)
                    Sum += Math.Pow(Cent[c][i] - X_Bar, 2);
                double Var = Sum / (n - 1);
                Var = Math.Sqrt(Var);

                double[] x_prim = new double[n];
                for (int i = 0; i < n; i++)
                    x_prim[i] = (Cent[c][i] - X_Bar) / Var;

                for (int i = 0; i < n; i++)
                    Cent[c][i] = 1 / (1 + Math.Exp(-x_prim[i]));
            }

        }

        private List<int> Final()
        {
            List<int> Result = new List<int>();
            for (int i = 0; i < Num_Com; i++)
            {
                for (int j = 0; j < Com_List[i].Count; j++)
                {
                    Result.Add(Com_List[i][j]);
                }
            }
            return Result;
        }
    }
}
