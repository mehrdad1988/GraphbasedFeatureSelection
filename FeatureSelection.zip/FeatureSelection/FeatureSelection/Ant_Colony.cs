﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FeatureSelection
{
    class Ant_Colony
    {
        double[,] W;
        List<List<int>> Com;
        List<Data> Train_Data;
        double[,] Eta;
        double[] Pheromon;
        int[] Fc;
        int Num_Feature;
        int Num_Community;
        int Iteration;
        int Ant_Number;
        int M;
        int Cycle_Lenght;
        double P;
        double q0;
        int[] Community;
        List<int>[] Com_List;
        double[] Information1;
        double Alfa = 1;
        double Beta = 1;
        double Com_Thereshold;

        public Ant_Colony(double[,] w, List<Data> train, int[] com, int num_com, double[] power, int iteration, int ant_num, int cycle_lenght, int m, double p, double q, double com_threshold)
        {
            W = w;
            Train_Data = train;
            Information1 = power;
            Eta = w;
            Num_Feature = Convert.ToInt32(Math.Sqrt(W.Length));
            Pheromon = new double[Num_Feature];
            Fc = new int[Num_Feature];
            Community = com;
            Iteration = iteration;
            Ant_Number = ant_num;
            Cycle_Lenght = cycle_lenght;
            M = m;
            Num_Community = num_com;
            P = p;
            q0 = q;
            Com_Thereshold = com_threshold;
            Com_List = new List<int>[Num_Community];
        }

        public List<int> Run_Ant_Community()
        {
            Random Rand = new Random();
            List<int> Result = new List<int>();
            Set_Initial_Pheromones();

            for (int i = 0; i < Iteration; i++)
            {
                Reset_F();
                for (int j = 0; j < Ant_Number; j++)
                {
                    List<int> Selected = new List<int>();
                    List<int> Selected_Community = new List<int>();
                    int Initial_Node = Rand.Next(Num_Feature);

                    Selected.Add(Initial_Node);
                    Selected_Community.Add(Community[Initial_Node]);
                    Fc[Initial_Node]++;
                    while (Selected_Community.Count != Num_Community)
                    {
                        int Select = Select_Feature(Selected, 1);
                        Selected.Add(Select);
                        Fc[Select]++;
                        if (!Selected_Community.Contains(Community[Select]))
                            Selected_Community.Add(Community[Select]);
                    }
                }
                Update_Pheromones();
            }
            return Finla_Select();
        }

        public List<int> Run_USFSACO()
        {
            Random Rand = new Random();
            List<int> Result = new List<int>();
            Set_Initial_Pheromones();
            for (int i = 0; i < Iteration; i++)
            {
                Reset_F();
                for (int j = 0; j < Ant_Number; j++)
                {
                    List<int> Selected = new List<int>();
                    int Initial_Node = Rand.Next(Num_Feature);
                    Selected.Add(Initial_Node);
                    Fc[Initial_Node]++;
                    for (int k = 0; k < Cycle_Lenght - 1; k++)
                    {
                        int Select = Select_Feature(Selected, 0);
                        Selected.Add(Select);
                        Fc[Select]++;
                    }
                }
                Update_Pheromones();
            }
            return Finla_Select();
        }

        public List<int> Run_Com_Com()
        {
            Random Rand = new Random();
            List<int> Result = new List<int>();
            List<int>[] Ant_Selected = new List<int>[Ant_Number];
            double[] Crit = new double[Ant_Number];
            Criterion criteration = new Criterion(Train_Data);
            criteration.Pre_Calculation();
            int select;
            double R;
            Set_Initial_Pheromones();
            Set_Com_List();


            for (int i = 0; i < Iteration; i++)
            {
                Reset_F();
                for (int j = 0; j < Ant_Number; j++)
                {
                    List<int> Remider_Com = new List<int>();
                    for (int ii = 0; ii < Num_Community; ii++)
                        Remider_Com.Add(ii);
                    List<int> Selected = new List<int>();
                    Ant_Selected[j] = new List<int>();
                    Ant_Selected[j].Clear();
                    while (Remider_Com.Count > 0)
                    {
                        int Rand_Com = Rand.Next(Remider_Com.Count);
                        int Com_Index = Remider_Com[Rand_Com];
                        select = Select_Feature_Com_Com(Selected, Com_Index);
                        Selected.Add(select);
                        Fc[select]++;
                        R = Rand.NextDouble();
                        if (R < Com_Thereshold)
                        {
                            Remider_Com.RemoveAt(Rand_Com);
                        }
                        else
                        {
                            int Selected_Number = 1;
                            while (R > Com_Thereshold && Selected_Number < Com_List[Com_Index].Count)
                            {
                                select = Select_Feature_Com_Com(Selected, Com_Index);
                                Selected.Add(select);
                                R = Rand.NextDouble();
                                Selected_Number++;
                                Fc[select]++;
                            }
                            Remider_Com.RemoveAt(Rand_Com);
                        }
                    }
                    for (int ii = 0; ii < Selected.Count; ii++)
                    {
                        Ant_Selected[j].Add(Selected[ii]);
                    }
                    Crit[j] = criteration.Calc_Criterion_Supervised2(Selected);
                }
                Ctrit_Normalization(ref Crit);
                Update_Pheomones_Crit(Ant_Selected, Crit);
                Update_Pheromones();
            }
            return Finla_Select();
        }

        void Update_Pheromones()
        {
            double Sigma_FC = 0;
            for (int i = 0; i < Num_Feature; i++)
                Sigma_FC += Fc[i];
            for (int i = 0; i < Num_Feature; i++)
                Pheromon[i] = ((1 - P) * Pheromon[i]) + ((double)Fc[i] / Sigma_FC);
        }

        void Update_Pheomones_Crit(List<int>[] ant_selected, double[] crit)
        {
            double[] Delta = new double[Num_Feature];
            int[] Num = new int[Num_Feature];

            for (int i = 0; i < Ant_Number; i++)
            {
                for (int j = 0; j < ant_selected[i].Count; j++)
                {
                    //Delta[ant_selected[i][j]] += crit[i] / ant_selected[i].Count;
                    Delta[ant_selected[i][j]] += crit[i];
                }
            }

            double Sigma_Ph = 0;
            for (int i = 0; i < Num_Feature; i++)
                Sigma_Ph += Delta[i];


            List<double> Crit_List = crit.ToList();
            double Max = Crit_List.Max();
            int Max_Index = Crit_List.IndexOf(Max);
            for (int i = 0; i < ant_selected[Max_Index].Count; i++)
            {
                Delta[ant_selected[Max_Index][i]] += 5 * crit[Max_Index];

            }

            for (int i = 0; i < Num_Feature; i++)
            {
                Pheromon[i] = 0.9 * Pheromon[i] + Delta[i];
            }
        }

        int Select_Feature(List<int> selected, int Type)
        {
            Random Rand = new Random();
            double q = Rand.NextDouble();
            List<int> UnSelected = new List<int>();

            List<double> P = new List<double>();

            for (int i = 0; i < Num_Feature; i++)
                if (!selected.Contains(i))
                    UnSelected.Add(i);

            int Count = UnSelected.Count;
            double[] Information2 = new double[UnSelected.Count];
            double[] Information3 = new double[UnSelected.Count];
            double[] Information4 = new double[UnSelected.Count];

            double Sigma = 0;
            double p = 0; ;
            for (int i = 0; i < Count; i++)
            {
                if (Type == 0) // 
                {
                    Information2[i] = Calc_Information2_Base(selected, UnSelected[i]);
                    p = Math.Pow(Pheromon[UnSelected[i]], Alfa) * Math.Pow(Information2[i], Beta);
                }
                if (Type == 1) //com
                {
                    Information2[i] = Calc_Information2_Inc(selected, UnSelected[i]);
                    Information3[i] = Calc_information3(selected, UnSelected[i]);
                    p = Math.Pow(Pheromon[UnSelected[i]], Alfa) * Math.Pow(Information2[i], Beta) * Information1[UnSelected[i]] * Information3[i];
                }
                if (Type == 2)
                {
                    Information4[i] = Calc_information4(selected, UnSelected[i]);
                    Information3[i] = Calc_information3(selected, UnSelected[i]);
                    p = Math.Pow(Pheromon[UnSelected[i]], Alfa) * Information4[i] * Information3[i];
                }
                P.Add(p);
                Sigma += p;
            }


            if (q < q0)
            {
                double Max = P.Max();
                int Max_Index = P.IndexOf(Max);
                return UnSelected[Max_Index];
            }

            else
            {
                double[] P_Cum = new double[Count];
                P_Cum[0] = P[0] / Sigma;
                double[] Cum = new double[Count];
                for (int i = 1; i < Count; i++)
                    P_Cum[i] = P_Cum[i - 1] + (P[i] / Sigma);

                double r = Rand.NextDouble();
                int index = 0;
                for (index = 0; index < Count; index++)
                {
                    if (r < P_Cum[index])
                        break;
                }
                return UnSelected[index];
            }
        }

        int Select_Feature_Com_Com(List<int> Selected, int com)
        {
            Random Rand = new Random();
            double q = Rand.NextDouble();
            List<int> UnSelected = new List<int>();

            List<double> P = new List<double>();
            double p = 0;
            double Sigma = 0;
            int Count = Com_List[com].Count;
            for (int i = 0; i < Count; i++)
                if (!Selected.Contains(Com_List[com][i]))
                    UnSelected.Add(Com_List[com][i]);


            if (Selected.Count > 0)
            {
                for (int i = 0; i < UnSelected.Count; i++)
                {
                    double inf1 = Information1[UnSelected[i]];
                    double inf2 = 0;
                    //for (int k = 0; k < Selected.Count; k++)
                    //    inf2 += 1 / W[UnSelected[i], Selected[k]];

                    for (int k = 0; k < Selected.Count; k++)
                        inf2 += W[UnSelected[i], Selected[k]];

                    inf2 = inf2 / Selected.Count;
                    //p = Math.Pow(Pheromon[UnSelected[i]], Alfa) * Math.Pow(inf1, Beta) * inf2;
                    p = Math.Pow(Pheromon[UnSelected[i]], Alfa) * Math.Pow((inf1 - inf2), 1);
                    P.Add(p);
                    Sigma += p;
                }
            }

            else
            {
                for (int i = 0; i < Count; i++)
                {
                    double inf1 = Information1[UnSelected[i]];
                    p = Math.Pow(Pheromon[UnSelected[i]], Alfa) * Math.Pow(inf1, 2);
                    P.Add(p);
                    Sigma += p;
                }
            }

            if (q < q0)
            {
                double Max = P.Max();
                int Max_Index = P.IndexOf(Max);
                return UnSelected[Max_Index];
            }

            else
            {
                double[] P_Cum = new double[Count];
                P_Cum[0] = P[0] / Sigma;
                double[] Cum = new double[Count];
                Count = P.Count;
                for (int i = 1; i < Count; i++)
                    P_Cum[i] = P_Cum[i - 1] + (P[i] / Sigma);

                double r = Rand.NextDouble();
                int index = 0;
                for (index = 0; index < Count; index++)
                {
                    if (r < P_Cum[index])
                        break;
                }
                return UnSelected[index];
            }
        }

        List<int> Finla_Select()
        {
            List<double> PH_List = new List<double>();
            List<int> PH_Index = new List<int>();
            List<int> Result = new List<int>();
            double Max;
            int Max_Index;

            for (int i = 0; i < Num_Feature; i++)
                PH_List.Add(Pheromon[i]);

            for (int i = 0; i < Num_Feature; i++)
                PH_Index.Add(i);

            for (int i = 0; i < M; i++)
            {
                Max = PH_List.Max();
                Max_Index = PH_List.IndexOf(Max);
                Result.Add(PH_Index[Max_Index]);
                PH_List.RemoveAt(Max_Index);
                PH_Index.RemoveAt(Max_Index);
            }
            return Result;
        }

        double Calc_information3(List<int> Selected, int i)
        {
            int Count = Selected.Count;
            double Sigma_Sim = 0;
            bool Flag = false;
            for (int ii = 0; ii < Count; ii++)
            {
                if (Community[i] == Community[Selected[ii]])
                    Sigma_Sim++;
            }
            return (1 / (Sigma_Sim + 1));
        }

        double Calc_information4(List<int> Selected, int i)
        {
            int Count = Selected.Count;
            double Sigma_Sim = 0;
            Sigma_Sim = W[i, Selected[Count - 1]];
            return (Information1[i] - Sigma_Sim);
        }

        double Calc_Information2_Inc(List<int> Selected, int i)
        {
            int Count = Selected.Count;
            double Sigma_Sim = 0;
            for (int ii = 0; ii < Count; ii++)
                Sigma_Sim += W[i, Selected[ii]];

            return (1 / ((1.0 / Count) * Sigma_Sim));
        }

        double Calc_Information2_Base(List<int> Selected, int i)
        {
            return 1 / (W[Selected[Selected.Count - 1], i] + 0.00001);
        }

        void Set_Initial_Pheromones()
        {
            for (int i = 0; i < Num_Feature; i++)
                Pheromon[i] = 0.2;
        }

        void Set_Initial_Pheromones_Power()
        {
            for (int i = 0; i < Num_Feature; i++)
                Pheromon[i] = Information1[i];
        }

        void Reset_F()
        {
            for (int i = 0; i < Num_Feature; i++)
                Fc[i] = 0;
        }

        void Set_Com_List()
        {

            for (int i = 0; i < Num_Community; i++)
            {
                Com_List[i] = new List<int>();
                for (int j = 0; j < Num_Feature; j++)
                {
                    if (Community[j] == i)
                        Com_List[i].Add(j);
                }
            }
        }

        private void Ctrit_Normalization(ref double[] Power)
        {
            int Num_Ant = Power.Length;

            double Max = double.MinValue;
            double Min = double.MaxValue;

            for (int i = 0; i < Num_Ant; i++)
            {
                if (Power[i] > Max)
                    Max = Power[i];

                if (Power[i] < Min)
                    Min = Power[i];
            }

            for (int i = 0; i < Num_Ant; i++)
            {
                Power[i] = (Power[i] - Min) / (Max - Min);
            }

        }
    }
}
