﻿namespace FeatureSelection
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.DataSet_Cmb = new System.Windows.Forms.ComboBox();
            this.Calc_Sim = new System.Windows.Forms.GroupBox();
            this.Normalized_Check = new System.Windows.Forms.CheckBox();
            this.Read_Com_Btn = new System.Windows.Forms.Button();
            this.Sim_Calc_Btn = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.Method_Cmb = new System.Windows.Forms.ComboBox();
            this.Read_Dataset_Btn = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Graph_Threshold_Txt = new System.Windows.Forms.NumericUpDown();
            this.Start_Btn = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.K_Txt = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.Ant_Number_Txt = new System.Windows.Forms.NumericUpDown();
            this.Selected_Feature_Num_Txt = new System.Windows.Forms.NumericUpDown();
            this.Cycle_Lenght_Txt = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.Iteration_Txt = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.Edge_Thereshold_Txt = new System.Windows.Forms.NumericUpDown();
            this.Com_Thereshold_Txt = new System.Windows.Forms.NumericUpDown();
            this.label8 = new System.Windows.Forms.Label();
            this.Number_Edge_Txt = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.Number_Node_Txt = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.Run_min_Time_Txt = new System.Windows.Forms.TextBox();
            this.Sim_min_Time_Txt = new System.Windows.Forms.TextBox();
            this.Run_s_Time_Txt = new System.Windows.Forms.TextBox();
            this.Sim_s_Time_Txt = new System.Windows.Forms.TextBox();
            this.Sum = new System.Windows.Forms.TextBox();
            this.Run_ms_Time_Txt = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.Sim_ms_Time_Txt = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.Calc_Sim.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Graph_Threshold_Txt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.K_Txt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ant_Number_Txt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Selected_Feature_Num_Txt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cycle_Lenght_Txt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Iteration_Txt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Edge_Thereshold_Txt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Com_Thereshold_Txt)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(5, 28);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(122, 20);
            this.label1.TabIndex = 6;
            this.label1.Text = "Dataset Name:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // DataSet_Cmb
            // 
            this.DataSet_Cmb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.DataSet_Cmb.FormattingEnabled = true;
            this.DataSet_Cmb.Items.AddRange(new object[] {
            "Sonar",
            "Diabetes",
            "Hepatitis",
            "Wine",
            "Ionosphere",
            "WDBC",
            "Arrhythmia",
            "Madelon",
            "Colon",
            "Multi Feature",
            "Arcene",
            "Isolet",
            "Leukemia",
            "Gisette",
            "SpamBase",
            "Lymphoma"});
            this.DataSet_Cmb.Location = new System.Drawing.Point(135, 25);
            this.DataSet_Cmb.Margin = new System.Windows.Forms.Padding(4);
            this.DataSet_Cmb.Name = "DataSet_Cmb";
            this.DataSet_Cmb.Size = new System.Drawing.Size(140, 28);
            this.DataSet_Cmb.TabIndex = 5;
            // 
            // Calc_Sim
            // 
            this.Calc_Sim.Controls.Add(this.Normalized_Check);
            this.Calc_Sim.Controls.Add(this.Read_Com_Btn);
            this.Calc_Sim.Controls.Add(this.Sim_Calc_Btn);
            this.Calc_Sim.Controls.Add(this.label5);
            this.Calc_Sim.Controls.Add(this.Method_Cmb);
            this.Calc_Sim.Controls.Add(this.Read_Dataset_Btn);
            this.Calc_Sim.Controls.Add(this.label1);
            this.Calc_Sim.Controls.Add(this.DataSet_Cmb);
            this.Calc_Sim.Location = new System.Drawing.Point(37, 36);
            this.Calc_Sim.Name = "Calc_Sim";
            this.Calc_Sim.Size = new System.Drawing.Size(307, 434);
            this.Calc_Sim.TabIndex = 7;
            this.Calc_Sim.TabStop = false;
            this.Calc_Sim.Text = "Loading";
            // 
            // Normalized_Check
            // 
            this.Normalized_Check.AutoSize = true;
            this.Normalized_Check.Checked = true;
            this.Normalized_Check.CheckState = System.Windows.Forms.CheckState.Checked;
            this.Normalized_Check.Location = new System.Drawing.Point(32, 60);
            this.Normalized_Check.Name = "Normalized_Check";
            this.Normalized_Check.Size = new System.Drawing.Size(198, 24);
            this.Normalized_Check.TabIndex = 20;
            this.Normalized_Check.Text = "Dataset Normalization";
            this.Normalized_Check.UseVisualStyleBackColor = true;
            // 
            // Read_Com_Btn
            // 
            this.Read_Com_Btn.Enabled = false;
            this.Read_Com_Btn.Location = new System.Drawing.Point(47, 353);
            this.Read_Com_Btn.Name = "Read_Com_Btn";
            this.Read_Com_Btn.Size = new System.Drawing.Size(210, 30);
            this.Read_Com_Btn.TabIndex = 19;
            this.Read_Com_Btn.Text = "Read Communities";
            this.Read_Com_Btn.UseVisualStyleBackColor = true;
            this.Read_Com_Btn.Click += new System.EventHandler(this.Read_Com_Btn_Click);
            // 
            // Sim_Calc_Btn
            // 
            this.Sim_Calc_Btn.Enabled = false;
            this.Sim_Calc_Btn.Location = new System.Drawing.Point(47, 262);
            this.Sim_Calc_Btn.Name = "Sim_Calc_Btn";
            this.Sim_Calc_Btn.Size = new System.Drawing.Size(210, 30);
            this.Sim_Calc_Btn.TabIndex = 18;
            this.Sim_Calc_Btn.Text = "Similarirty Computation";
            this.Sim_Calc_Btn.UseVisualStyleBackColor = true;
            this.Sim_Calc_Btn.Click += new System.EventHandler(this.Sim_Calc_Btn_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(71, 191);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 20);
            this.label5.TabIndex = 15;
            this.label5.Text = "Method:";
            // 
            // Method_Cmb
            // 
            this.Method_Cmb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Method_Cmb.FormattingEnabled = true;
            this.Method_Cmb.Items.AddRange(new object[] {
            "Term_Variance",
            "Laplacian-Score",
            "Fisher-Score",
            "Constraint-Score",
            "UFSACO",
            "GCACO",
            "U_GCNC",
            "S_GCNC",
            "GCGA_Random",
            "GCGA_Score"});
            this.Method_Cmb.Location = new System.Drawing.Point(146, 190);
            this.Method_Cmb.Name = "Method_Cmb";
            this.Method_Cmb.Size = new System.Drawing.Size(140, 28);
            this.Method_Cmb.TabIndex = 14;
            this.Method_Cmb.SelectedIndexChanged += new System.EventHandler(this.Method_Cmb_SelectedIndexChanged);
            // 
            // Read_Dataset_Btn
            // 
            this.Read_Dataset_Btn.Location = new System.Drawing.Point(47, 97);
            this.Read_Dataset_Btn.Name = "Read_Dataset_Btn";
            this.Read_Dataset_Btn.Size = new System.Drawing.Size(210, 30);
            this.Read_Dataset_Btn.TabIndex = 7;
            this.Read_Dataset_Btn.Text = "Read_Dataset";
            this.Read_Dataset_Btn.UseVisualStyleBackColor = true;
            this.Read_Dataset_Btn.Click += new System.EventHandler(this.Read_Dataset_Btn_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.Graph_Threshold_Txt);
            this.groupBox1.Controls.Add(this.Start_Btn);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.K_Txt);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.Ant_Number_Txt);
            this.groupBox1.Controls.Add(this.Selected_Feature_Num_Txt);
            this.groupBox1.Controls.Add(this.Cycle_Lenght_Txt);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.Iteration_Txt);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.Edge_Thereshold_Txt);
            this.groupBox1.Controls.Add(this.Com_Thereshold_Txt);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Location = new System.Drawing.Point(392, 36);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(307, 434);
            this.groupBox1.TabIndex = 20;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Setting";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(51, 316);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(148, 20);
            this.label2.TabIndex = 44;
            this.label2.Text = "Graph Thereshold:";
            // 
            // Graph_Threshold_Txt
            // 
            this.Graph_Threshold_Txt.DecimalPlaces = 2;
            this.Graph_Threshold_Txt.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.Graph_Threshold_Txt.Location = new System.Drawing.Point(217, 314);
            this.Graph_Threshold_Txt.Maximum = new decimal(new int[] {
            75,
            0,
            0,
            131072});
            this.Graph_Threshold_Txt.Name = "Graph_Threshold_Txt";
            this.Graph_Threshold_Txt.Size = new System.Drawing.Size(52, 26);
            this.Graph_Threshold_Txt.TabIndex = 43;
            this.Graph_Threshold_Txt.Value = new decimal(new int[] {
            15,
            0,
            0,
            131072});
            // 
            // Start_Btn
            // 
            this.Start_Btn.Enabled = false;
            this.Start_Btn.Location = new System.Drawing.Point(48, 372);
            this.Start_Btn.Name = "Start_Btn";
            this.Start_Btn.Size = new System.Drawing.Size(210, 30);
            this.Start_Btn.TabIndex = 42;
            this.Start_Btn.Text = "Start";
            this.Start_Btn.UseVisualStyleBackColor = true;
            this.Start_Btn.Click += new System.EventHandler(this.Start_Btn_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(128, 154);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(68, 20);
            this.label14.TabIndex = 41;
            this.label14.Text = "Omega:";
            // 
            // K_Txt
            // 
            this.K_Txt.Location = new System.Drawing.Point(217, 154);
            this.K_Txt.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.K_Txt.Name = "K_Txt";
            this.K_Txt.Size = new System.Drawing.Size(52, 26);
            this.K_Txt.TabIndex = 40;
            this.K_Txt.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(121, 36);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 20);
            this.label3.TabIndex = 29;
            this.label3.Text = "Iteration:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(92, 76);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(103, 20);
            this.label4.TabIndex = 31;
            this.label4.Text = "Ant Number:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(84, 116);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(112, 20);
            this.label10.TabIndex = 39;
            this.label10.Text = "Cycle Lenght:";
            // 
            // Ant_Number_Txt
            // 
            this.Ant_Number_Txt.Location = new System.Drawing.Point(217, 74);
            this.Ant_Number_Txt.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.Ant_Number_Txt.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.Ant_Number_Txt.Name = "Ant_Number_Txt";
            this.Ant_Number_Txt.Size = new System.Drawing.Size(52, 26);
            this.Ant_Number_Txt.TabIndex = 30;
            this.Ant_Number_Txt.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // Selected_Feature_Num_Txt
            // 
            this.Selected_Feature_Num_Txt.Location = new System.Drawing.Point(217, 194);
            this.Selected_Feature_Num_Txt.Minimum = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.Selected_Feature_Num_Txt.Name = "Selected_Feature_Num_Txt";
            this.Selected_Feature_Num_Txt.Size = new System.Drawing.Size(52, 26);
            this.Selected_Feature_Num_Txt.TabIndex = 32;
            this.Selected_Feature_Num_Txt.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // Cycle_Lenght_Txt
            // 
            this.Cycle_Lenght_Txt.Location = new System.Drawing.Point(217, 114);
            this.Cycle_Lenght_Txt.Minimum = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.Cycle_Lenght_Txt.Name = "Cycle_Lenght_Txt";
            this.Cycle_Lenght_Txt.Size = new System.Drawing.Size(52, 26);
            this.Cycle_Lenght_Txt.TabIndex = 38;
            this.Cycle_Lenght_Txt.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(58, 196);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(141, 20);
            this.label7.TabIndex = 33;
            this.label7.Text = "Selected Feature:";
            // 
            // Iteration_Txt
            // 
            this.Iteration_Txt.Location = new System.Drawing.Point(217, 34);
            this.Iteration_Txt.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.Iteration_Txt.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.Iteration_Txt.Name = "Iteration_Txt";
            this.Iteration_Txt.Size = new System.Drawing.Size(52, 26);
            this.Iteration_Txt.TabIndex = 28;
            this.Iteration_Txt.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(62, 276);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(137, 20);
            this.label9.TabIndex = 37;
            this.label9.Text = "Com Thereshold:";
            // 
            // Edge_Thereshold_Txt
            // 
            this.Edge_Thereshold_Txt.DecimalPlaces = 2;
            this.Edge_Thereshold_Txt.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.Edge_Thereshold_Txt.Location = new System.Drawing.Point(217, 234);
            this.Edge_Thereshold_Txt.Maximum = new decimal(new int[] {
            9,
            0,
            0,
            65536});
            this.Edge_Thereshold_Txt.Name = "Edge_Thereshold_Txt";
            this.Edge_Thereshold_Txt.Size = new System.Drawing.Size(52, 26);
            this.Edge_Thereshold_Txt.TabIndex = 34;
            this.Edge_Thereshold_Txt.Value = new decimal(new int[] {
            4,
            0,
            0,
            65536});
            // 
            // Com_Thereshold_Txt
            // 
            this.Com_Thereshold_Txt.DecimalPlaces = 2;
            this.Com_Thereshold_Txt.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.Com_Thereshold_Txt.Location = new System.Drawing.Point(217, 274);
            this.Com_Thereshold_Txt.Maximum = new decimal(new int[] {
            75,
            0,
            0,
            131072});
            this.Com_Thereshold_Txt.Name = "Com_Thereshold_Txt";
            this.Com_Thereshold_Txt.Size = new System.Drawing.Size(52, 26);
            this.Com_Thereshold_Txt.TabIndex = 36;
            this.Com_Thereshold_Txt.Value = new decimal(new int[] {
            4,
            0,
            0,
            65536});
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(56, 236);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(140, 20);
            this.label8.TabIndex = 35;
            this.label8.Text = "Edge Thereshold:";
            // 
            // Number_Edge_Txt
            // 
            this.Number_Edge_Txt.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.Number_Edge_Txt.Enabled = false;
            this.Number_Edge_Txt.Location = new System.Drawing.Point(869, 109);
            this.Number_Edge_Txt.Name = "Number_Edge_Txt";
            this.Number_Edge_Txt.Size = new System.Drawing.Size(109, 26);
            this.Number_Edge_Txt.TabIndex = 24;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(751, 109);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(139, 20);
            this.label12.TabIndex = 23;
            this.label12.Text = "Number Of Edge:";
            // 
            // Number_Node_Txt
            // 
            this.Number_Node_Txt.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.Number_Node_Txt.Enabled = false;
            this.Number_Node_Txt.Location = new System.Drawing.Point(869, 64);
            this.Number_Node_Txt.Name = "Number_Node_Txt";
            this.Number_Node_Txt.Size = new System.Drawing.Size(109, 26);
            this.Number_Node_Txt.TabIndex = 22;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(751, 64);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(140, 20);
            this.label11.TabIndex = 21;
            this.label11.Text = "Number Of Node:";
            // 
            // Run_min_Time_Txt
            // 
            this.Run_min_Time_Txt.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.Run_min_Time_Txt.Enabled = false;
            this.Run_min_Time_Txt.Location = new System.Drawing.Point(780, 253);
            this.Run_min_Time_Txt.Name = "Run_min_Time_Txt";
            this.Run_min_Time_Txt.Size = new System.Drawing.Size(72, 26);
            this.Run_min_Time_Txt.TabIndex = 46;
            // 
            // Sim_min_Time_Txt
            // 
            this.Sim_min_Time_Txt.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.Sim_min_Time_Txt.Enabled = false;
            this.Sim_min_Time_Txt.Location = new System.Drawing.Point(780, 221);
            this.Sim_min_Time_Txt.Name = "Sim_min_Time_Txt";
            this.Sim_min_Time_Txt.Size = new System.Drawing.Size(72, 26);
            this.Sim_min_Time_Txt.TabIndex = 45;
            // 
            // Run_s_Time_Txt
            // 
            this.Run_s_Time_Txt.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.Run_s_Time_Txt.Enabled = false;
            this.Run_s_Time_Txt.Location = new System.Drawing.Point(858, 253);
            this.Run_s_Time_Txt.Name = "Run_s_Time_Txt";
            this.Run_s_Time_Txt.Size = new System.Drawing.Size(72, 26);
            this.Run_s_Time_Txt.TabIndex = 44;
            // 
            // Sim_s_Time_Txt
            // 
            this.Sim_s_Time_Txt.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.Sim_s_Time_Txt.Enabled = false;
            this.Sim_s_Time_Txt.Location = new System.Drawing.Point(858, 221);
            this.Sim_s_Time_Txt.Name = "Sim_s_Time_Txt";
            this.Sim_s_Time_Txt.Size = new System.Drawing.Size(72, 26);
            this.Sim_s_Time_Txt.TabIndex = 43;
            // 
            // Sum
            // 
            this.Sum.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.Sum.Enabled = false;
            this.Sum.Location = new System.Drawing.Point(935, 294);
            this.Sum.Name = "Sum";
            this.Sum.Size = new System.Drawing.Size(73, 26);
            this.Sum.TabIndex = 42;
            // 
            // Run_ms_Time_Txt
            // 
            this.Run_ms_Time_Txt.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.Run_ms_Time_Txt.Enabled = false;
            this.Run_ms_Time_Txt.Location = new System.Drawing.Point(936, 253);
            this.Run_ms_Time_Txt.Name = "Run_ms_Time_Txt";
            this.Run_ms_Time_Txt.Size = new System.Drawing.Size(72, 26);
            this.Run_ms_Time_Txt.TabIndex = 41;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(736, 256);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(49, 20);
            this.label17.TabIndex = 40;
            this.label17.Text = "Run: ";
            // 
            // Sim_ms_Time_Txt
            // 
            this.Sim_ms_Time_Txt.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.Sim_ms_Time_Txt.Enabled = false;
            this.Sim_ms_Time_Txt.Location = new System.Drawing.Point(936, 221);
            this.Sim_ms_Time_Txt.Name = "Sim_ms_Time_Txt";
            this.Sim_ms_Time_Txt.Size = new System.Drawing.Size(72, 26);
            this.Sim_ms_Time_Txt.TabIndex = 39;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(705, 224);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(88, 20);
            this.label16.TabIndex = 38;
            this.label16.Text = "Similarity: ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(732, 294);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 20);
            this.label6.TabIndex = 47;
            this.label6.Text = "Sum: ";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(952, 192);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(32, 20);
            this.label13.TabIndex = 48;
            this.label13.Text = "ms";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(879, 192);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(18, 20);
            this.label15.TabIndex = 48;
            this.label15.Text = "s";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(798, 192);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(36, 20);
            this.label18.TabIndex = 48;
            this.label18.Text = "min";
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1022, 537);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Run_min_Time_Txt);
            this.Controls.Add(this.Sim_min_Time_Txt);
            this.Controls.Add(this.Run_s_Time_Txt);
            this.Controls.Add(this.Sim_s_Time_Txt);
            this.Controls.Add(this.Sum);
            this.Controls.Add(this.Run_ms_Time_Txt);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.Sim_ms_Time_Txt);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.Number_Edge_Txt);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.Number_Node_Txt);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.Calc_Sim);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Main";
            this.Text = "Feature Selection";
            this.Load += new System.EventHandler(this.Main_Load);
            this.Calc_Sim.ResumeLayout(false);
            this.Calc_Sim.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Graph_Threshold_Txt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.K_Txt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ant_Number_Txt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Selected_Feature_Num_Txt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cycle_Lenght_Txt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Iteration_Txt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Edge_Thereshold_Txt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Com_Thereshold_Txt)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox DataSet_Cmb;
        private System.Windows.Forms.GroupBox Calc_Sim;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox Method_Cmb;
        private System.Windows.Forms.Button Read_Dataset_Btn;
        private System.Windows.Forms.Button Sim_Calc_Btn;
        private System.Windows.Forms.Button Read_Com_Btn;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.NumericUpDown K_Txt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.NumericUpDown Ant_Number_Txt;
        private System.Windows.Forms.NumericUpDown Selected_Feature_Num_Txt;
        private System.Windows.Forms.NumericUpDown Cycle_Lenght_Txt;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown Iteration_Txt;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.NumericUpDown Edge_Thereshold_Txt;
        private System.Windows.Forms.NumericUpDown Com_Thereshold_Txt;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button Start_Btn;
        private System.Windows.Forms.CheckBox Normalized_Check;
        private System.Windows.Forms.TextBox Number_Edge_Txt;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox Number_Node_Txt;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown Graph_Threshold_Txt;
        private System.Windows.Forms.TextBox Run_min_Time_Txt;
        private System.Windows.Forms.TextBox Sim_min_Time_Txt;
        private System.Windows.Forms.TextBox Run_s_Time_Txt;
        private System.Windows.Forms.TextBox Sim_s_Time_Txt;
        private System.Windows.Forms.TextBox Sum;
        private System.Windows.Forms.TextBox Run_ms_Time_Txt;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox Sim_ms_Time_Txt;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label18;
    }
}

